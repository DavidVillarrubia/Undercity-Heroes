//
//  AppDelegate.h
//  Undercity Heroes
//
//  Created by David on 9/4/18.
//  Copyright © 2018 David. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property BOOL restrictRotation;

@end


//
//  ViewController.h
//  Undercity Heroes
//
//  Created by David on 9/4/18.
//  Copyright © 2018 David. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
{
    NSMutableDictionary *minion1;
    int posicionMinion1X;
    int posicionMinion1Y;
    NSMutableDictionary *minion2;
    int posicionMinion2X;
    int posicionMinion2Y;
    NSMutableDictionary *minion3;
    int posicionMinion3X;
    int posicionMinion3Y;
    NSMutableDictionary *minion4;
    int posicionMinion4X;
    int posicionMinion4Y;
    NSMutableDictionary *minion5;
    int posicionMinion5X;
    int posicionMinion5Y;
    NSMutableDictionary *boss;
    int posicionMinionBX;
    int posicionMinionBY;
    
    
    
    NSMutableDictionary *heroe1;
    NSMutableDictionary *heroe2;
    NSMutableDictionary *heroe3;
    NSMutableDictionary *heroe4;
    
    int turnos;
    int posicion1;
    int posicion2;
    
    NSMutableDictionary *player1;
    NSMutableDictionary *player2;
    NSMutableDictionary *player3;
    NSMutableDictionary *player4;
    
    NSMutableArray *tablero;
    
    
    NSMutableArray *inventarioHeroe1;
    NSMutableArray *inventarioHeroe2;
    NSMutableArray *inventarioHeroe3;
    NSMutableArray *inventarioHeroe4;
    
    NSMutableDictionary *objetoVacio;
    
    bool mostrandoInventario;
    
    bool favordeDioses;
    NSString *personajeFavorDioses;
    bool pocionChaman;
    NSString *personajeChaman;
    

    //El héroe solo podrá hacer 2 acciones en su turno
    int contadorAcciones;
    
    int players;
}

@property (weak, nonatomic) IBOutlet UIButton *arriba;
- (IBAction)botonArriba:(id)sender;
@property (weak, nonatomic) IBOutlet UIButton *abajo;
- (IBAction)botonAbajo:(id)sender;

@property (weak, nonatomic) IBOutlet UIButton *izquierda;
- (IBAction)botonIzquierda:(id)sender;

@property (weak, nonatomic) IBOutlet UIButton *derecha;
- (IBAction)botonDerecha:(id)sender;


@property (weak, nonatomic) IBOutlet UIImageView *iconoVidaHeroe1;
@property (weak, nonatomic) IBOutlet UIImageView *iconoVidaHeroe2;
@property (weak, nonatomic) IBOutlet UIImageView *iconoVidaHeroe3;
@property (weak, nonatomic) IBOutlet UIImageView *iconoVidaHeroe4;
@property (weak, nonatomic) IBOutlet UIImageView *iconoVidaMinion1;
@property (weak, nonatomic) IBOutlet UIImageView *iconoVidaMinion2;
@property (weak, nonatomic) IBOutlet UIImageView *iconoVidaMinion3;
@property (weak, nonatomic) IBOutlet UIImageView *iconoVidaMinion4;
@property (weak, nonatomic) IBOutlet UIImageView *iconoVidaMinion5;
@property (weak, nonatomic) IBOutlet UIImageView *iconoVidaBoss;


@property (weak, nonatomic) IBOutlet UIButton *botonTerminar;
- (IBAction)terminar:(id)sender;



@property (strong,nonatomic) IBOutlet UIButton *minion1Img;
@property (strong,nonatomic) IBOutlet UIButton *minion2Img;
@property (strong,nonatomic) IBOutlet UIButton *minion3Img;
@property (strong,nonatomic) IBOutlet UIButton *minion4Img;
@property (strong,nonatomic) IBOutlet UIButton *minion5Img;
@property (strong,nonatomic) IBOutlet UIButton *bossImg;
@property (strong,nonatomic) IBOutlet UIButton *heroe1Img;
@property (strong,nonatomic) IBOutlet UIButton *heroe2Img;
@property (strong,nonatomic) IBOutlet UIButton *heroe3Img;
@property (strong,nonatomic) IBOutlet UIButton *heroe4Img;


@property (weak, nonatomic) IBOutlet UIView *mapa;
@property (weak, nonatomic) IBOutlet UILabel *nombreHeroe;
@property (weak, nonatomic) IBOutlet UILabel *vidaHeroe;
@property (weak, nonatomic) IBOutlet UILabel *nombreMinion1;
@property (weak, nonatomic) IBOutlet UILabel *vidaMinion1;
@property (weak, nonatomic) IBOutlet UILabel *nombreMinion2;
@property (weak, nonatomic) IBOutlet UILabel *vidaMinion2;
@property (weak, nonatomic) IBOutlet UILabel *nombreMinion3;
@property (weak, nonatomic) IBOutlet UILabel *vidaMinion3;
@property (weak, nonatomic) IBOutlet UILabel *nombreMinion4;
@property (weak, nonatomic) IBOutlet UILabel *vidaMinion4;
@property (weak, nonatomic) IBOutlet UILabel *nombreMinion5;
@property (weak, nonatomic) IBOutlet UILabel *vidaMinion5;
@property (weak, nonatomic) IBOutlet UILabel *nombreBoss;
@property (weak, nonatomic) IBOutlet UILabel *vidaBoss;


@property (strong,nonatomic) IBOutlet UIButton *boton1;
@property (strong,nonatomic) IBOutlet UIButton *boton2;
@property (strong,nonatomic) IBOutlet UIButton *boton3;
@property (strong,nonatomic) IBOutlet UIButton *boton4;
@property (strong,nonatomic) IBOutlet UIButton *boton5;
@property (strong,nonatomic) IBOutlet UIButton *boton6;
@property (strong,nonatomic) IBOutlet UIButton *boton7;
@property (strong,nonatomic) IBOutlet UIButton *boton8;
@property (strong,nonatomic) IBOutlet UIButton *boton9;
@property (strong,nonatomic) IBOutlet UIButton *boton10;
@property (strong,nonatomic) IBOutlet UIButton *boton11;
@property (strong,nonatomic) IBOutlet UIButton *boton12;

- (IBAction)usoObjeto1:(id)sender;
- (IBAction)usoObjeto2:(id)sender;
- (IBAction)usoObjeto3:(id)sender;
- (IBAction)usoObjeto4:(id)sender;
- (IBAction)usoObjeto5:(id)sender;
- (IBAction)usoObjeto6:(id)sender;
- (IBAction)usoObjeto7:(id)sender;
- (IBAction)usoObjeto8:(id)sender;
- (IBAction)usoObjeto9:(id)sender;
- (IBAction)usoObjeto10:(id)sender;
- (IBAction)usoObjeto11:(id)sender;
- (IBAction)usoObjeto12:(id)sender;

- (IBAction)verinventario:(id)sender;
@property (weak, nonatomic) IBOutlet UIButton *inventario;


//PASILLO 1
@property (weak, nonatomic) IBOutlet UIButton *pasillo11;
@property (weak, nonatomic) IBOutlet UIButton *pasillo12;
@property (weak, nonatomic) IBOutlet UIButton *pasillo13;
@property (weak, nonatomic) IBOutlet UIButton *pasillo14;
@property (weak, nonatomic) IBOutlet UIButton *pasillo15;
@property (weak, nonatomic) IBOutlet UIButton *pasillo16;
@property (weak, nonatomic) IBOutlet UIButton *pasillo17;
@property (weak, nonatomic) IBOutlet UIButton *pasillo18;
@property (weak, nonatomic) IBOutlet UIButton *pasillo19;
@property (weak, nonatomic) IBOutlet UIButton *pasillo110;
@property (weak, nonatomic) IBOutlet UIButton *pasillo111;
@property (weak, nonatomic) IBOutlet UIButton *pasillo112;
@property (weak, nonatomic) IBOutlet UIButton *pasillo113;
@property (weak, nonatomic) IBOutlet UIButton *pasillo114;
- (IBAction)cofreIz:(id)sender;
- (IBAction)cofreDe:(id)sender;


//PASILLO 2
@property (weak, nonatomic) IBOutlet UIButton *pasillo21;
@property (weak, nonatomic) IBOutlet UIButton *pasillo22;
@property (weak, nonatomic) IBOutlet UIButton *pasillo23;
@property (weak, nonatomic) IBOutlet UIButton *pasillo24;
@property (weak, nonatomic) IBOutlet UIButton *pasillo25;
@property (weak, nonatomic) IBOutlet UIButton *pasillo26;
@property (weak, nonatomic) IBOutlet UIButton *pasillo27;
@property (weak, nonatomic) IBOutlet UIButton *pasillo28;
@property (weak, nonatomic) IBOutlet UIButton *pasillo29;
@property (weak, nonatomic) IBOutlet UIButton *pasillo210;
@property (weak, nonatomic) IBOutlet UIButton *pasillo211;
@property (weak, nonatomic) IBOutlet UIButton *pasillo212;
- (IBAction)pasillo21Accion:(id)sender;
- (IBAction)pasillo22Accion:(id)sender;
- (IBAction)pasillo23Accion:(id)sender;
- (IBAction)pasillo24Accion:(id)sender;
- (IBAction)pasillo25Accion:(id)sender;
- (IBAction)pasillo26Accion:(id)sender;
- (IBAction)pasillo27Accion:(id)sender;
- (IBAction)pasillo28Accion:(id)sender;
- (IBAction)pasillo29Accion:(id)sender;
- (IBAction)pasillo210Accion:(id)sender;
- (IBAction)pasillo211Accion:(id)sender;
- (IBAction)pasillo212Accion:(id)sender;

//SALÓN
@property (weak, nonatomic) IBOutlet UIButton *salon1;
@property (weak, nonatomic) IBOutlet UIButton *salon2;
@property (weak, nonatomic) IBOutlet UIButton *salon3;
@property (weak, nonatomic) IBOutlet UIButton *salon4;
@property (weak, nonatomic) IBOutlet UIButton *salon5;
@property (weak, nonatomic) IBOutlet UIButton *salon6;
@property (weak, nonatomic) IBOutlet UIButton *salon7;
@property (weak, nonatomic) IBOutlet UIButton *salon8;
@property (weak, nonatomic) IBOutlet UIButton *salon9;
@property (weak, nonatomic) IBOutlet UIButton *salon10;
@property (weak, nonatomic) IBOutlet UIButton *salon11;
@property (weak, nonatomic) IBOutlet UIButton *salon12;
- (IBAction)salon1Accion:(id)sender;
- (IBAction)salon2Accion:(id)sender;
- (IBAction)salon3Accion:(id)sender;
- (IBAction)salon4Accion:(id)sender;
- (IBAction)salon5Accion:(id)sender;
- (IBAction)salon6Accion:(id)sender;
- (IBAction)salon7Accion:(id)sender;
- (IBAction)salon8Accion:(id)sender;
- (IBAction)salon9Accion:(id)sender;
- (IBAction)salon10Accion:(id)sender;
- (IBAction)salon11Accion:(id)sender;
- (IBAction)salon12Accion:(id)sender;

//POSICIONES SALIDA
@property (weak, nonatomic) IBOutlet UIButton *salida1;
@property (weak, nonatomic) IBOutlet UIButton *salida2;
@property (weak, nonatomic) IBOutlet UIButton *salida3;
@property (weak, nonatomic) IBOutlet UIButton *salida4;
- (IBAction)salida1Accion:(id)sender;
- (IBAction)salida2Accion:(id)sender;
- (IBAction)salida3Accion:(id)sender;
- (IBAction)salida4Accion:(id)sender;

@end


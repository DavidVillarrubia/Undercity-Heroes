//
//  ViewController.m
//  Undercity Heroes
//
//  Created by David on 9/4/18.
//  Copyright © 2018 David. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController


-(void)jugadores:(int)players{
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Bienvenido, Aventurero/a/e" message:@"Escoge tu personaje" preferredStyle:UIAlertControllerStyleAlert];
    self.iconoVidaHeroe1.hidden=true;
    self.iconoVidaHeroe1.image=[UIImage imageNamed:@"Heart.png" inBundle:[NSBundle bundleForClass:self.class] compatibleWithTraitCollection:nil];
    
    UIAlertAction* action1 = [UIAlertAction actionWithTitle:[NSString stringWithFormat:@"%@, el %@",[heroe1 valueForKey:@"nombre"],[heroe1 valueForKey:@"clase"]] style:UIAlertActionStyleDefault handler:^(UIAlertAction *action){[self dismissViewControllerAnimated:YES completion:^{}];
        [self alertas:@"HAS ESCOGIDO A" withMessage:[NSString stringWithFormat:@"%@, el %@",[self->heroe1 valueForKey:@"nombre"],[self->heroe1 valueForKey:@"clase"]]];
        
        
        self->player1=[self->heroe1 mutableCopy];
        
        self.nombreHeroe.text=[self->heroe1 valueForKey:@"nombre"];
        self.vidaHeroe.text=[NSString stringWithFormat:@"%@",[self->heroe1 valueForKey:@"vida"]];
        self.nombreHeroe.adjustsFontSizeToFitWidth = YES;
        
        self.iconoVidaHeroe1.hidden=false;
        self.pasillo11.backgroundColor=[UIColor redColor];
    }];
    [alert addAction:action1];
    
    UIAlertAction* action2 = [UIAlertAction actionWithTitle:[NSString stringWithFormat:@"%@, el %@",[heroe2 valueForKey:@"nombre"],[heroe2 valueForKey:@"clase"]] style:UIAlertActionStyleDefault handler:^(UIAlertAction *action){[self dismissViewControllerAnimated:YES completion:^{}];
        [self alertas:@"HAS ESCOGIDO A" withMessage:[NSString stringWithFormat:@"%@, el %@",[self->heroe2 valueForKey:@"nombre"],[self->heroe2 valueForKey:@"clase"]]];
        
        self->player1=[self->heroe2 mutableCopy];
        
        self.nombreHeroe.text=[self->heroe2 valueForKey:@"nombre"];
        self.vidaHeroe.text=[NSString stringWithFormat:@"%@",[self->heroe2 valueForKey:@"vida"]];
        self.nombreHeroe.adjustsFontSizeToFitWidth = YES;
        self.iconoVidaHeroe1.hidden=false;
        self.pasillo11.backgroundColor=[UIColor redColor];
    }];
    [alert addAction:action2];
    
    
    UIAlertAction* action3 = [UIAlertAction actionWithTitle:[NSString stringWithFormat:@"%@, la %@",[heroe3 valueForKey:@"nombre"],[heroe3 valueForKey:@"clase"]] style:UIAlertActionStyleDefault handler:^(UIAlertAction *action){[self dismissViewControllerAnimated:YES completion:^{}];
        [self alertas:@"HAS ESCOGIDO A" withMessage:[NSString stringWithFormat:@"%@, la %@",[self->heroe3 valueForKey:@"nombre"],[self->heroe3 valueForKey:@"clase"]]];
        
        self->player1=[self->heroe3 mutableCopy];
        
        self.nombreHeroe.text=[self->heroe3 valueForKey:@"nombre"];
        self.vidaHeroe.text=[NSString stringWithFormat:@"%@",[self->heroe3 valueForKey:@"vida"]];
        self.nombreHeroe.adjustsFontSizeToFitWidth = YES;
        self.iconoVidaHeroe1.hidden=false;
        self.pasillo11.backgroundColor=[UIColor redColor];
    }];
    [alert addAction:action3];
    
    
    UIAlertAction* action4 = [UIAlertAction actionWithTitle:[NSString stringWithFormat:@"%@, la %@",[heroe4 valueForKey:@"nombre"],[heroe4 valueForKey:@"clase"]] style:UIAlertActionStyleDefault handler:^(UIAlertAction *action){[self dismissViewControllerAnimated:YES completion:^{}];
        [self alertas:@"HAS ESCOGIDO A" withMessage:[NSString stringWithFormat:@"%@, la %@",[self->heroe4 valueForKey:@"nombre"],[self->heroe4 valueForKey:@"clase"]]];
        
        self->player1=[self->heroe4 mutableCopy];
        
        self.nombreHeroe.text=[self->heroe4 valueForKey:@"nombre"];
        self.vidaHeroe.text=[NSString stringWithFormat:@"%@",[self->heroe4 valueForKey:@"vida"]];
        self.nombreHeroe.adjustsFontSizeToFitWidth = YES;
        self.iconoVidaHeroe1.hidden=false;
        self.pasillo11.backgroundColor=[UIColor redColor];
    }];
    [alert addAction:action4];
    
    [self presentViewController:alert animated:YES completion:nil];
    self.pasillo11.enabled=true;
}

//REVISAR MOVIMIENTO ZOMBIES: PASAN POR ENCIMA DE OTROS ZOMBIES, HACIÉNDOLES DESAPARECER
- (void)viewDidLoad {
    [super viewDidLoad];
    
    contadorAcciones=2;
    
    personajeChaman=@"";
    pocionChaman=false;
    personajeFavorDioses=@"";
    personajeFavorDioses=false;
    
    mostrandoInventario=false;
    self.boton1.enabled=false;
    self.boton1.hidden=true;
    self.boton2.enabled=false;
    self.boton2.hidden=true;
    self.boton3.enabled=false;
    self.boton3.hidden=true;
    self.boton4.enabled=false;
    self.boton4.hidden=true;
    self.boton5.enabled=false;
    self.boton5.hidden=true;
    self.boton6.enabled=false;
    self.boton6.hidden=true;
    self.boton7.enabled=false;
    self.boton7.hidden=true;
    self.boton8.enabled=false;
    self.boton8.hidden=true;
    self.boton9.enabled=false;
    self.boton9.hidden=true;
    self.boton10.enabled=false;
    self.boton10.hidden=true;
    self.boton11.enabled=false;
    self.boton11.hidden=true;
    self.boton12.enabled=false;
    self.boton12.hidden=true;
    
    self.arriba.enabled=true;
    self.arriba.hidden=false;
    self.abajo.enabled=true;
    self.abajo.hidden=false;
    self.izquierda.enabled=true;
    self.izquierda.hidden=false;
    self.derecha.enabled=true;
    self.derecha.hidden=false;

    
    objetoVacio=[[NSMutableDictionary alloc]initWithObjectsAndKeys:@"",@"nombre", nil];
    inventarioHeroe1=[[NSMutableArray alloc]initWithObjects:[[NSMutableDictionary alloc]initWithObjectsAndKeys:@"",@"nombre", nil],[[NSMutableDictionary alloc]initWithObjectsAndKeys:@"",@"nombre", nil],[[NSMutableDictionary alloc]initWithObjectsAndKeys:@"",@"nombre", nil],[[NSMutableDictionary alloc]initWithObjectsAndKeys:@"",@"nombre", nil],[[NSMutableDictionary alloc]initWithObjectsAndKeys:@"",@"nombre", nil],[[NSMutableDictionary alloc]initWithObjectsAndKeys:@"",@"nombre", nil],[[NSMutableDictionary alloc]initWithObjectsAndKeys:@"",@"nombre", nil],[[NSMutableDictionary alloc]initWithObjectsAndKeys:@"",@"nombre", nil],[[NSMutableDictionary alloc]initWithObjectsAndKeys:@"",@"nombre", nil],[[NSMutableDictionary alloc]initWithObjectsAndKeys:@"",@"nombre", nil],[[NSMutableDictionary alloc]initWithObjectsAndKeys:@"",@"nombre", nil],[[NSMutableDictionary alloc]initWithObjectsAndKeys:@"",@"nombre", nil], nil];
    inventarioHeroe2=[[NSMutableArray alloc]initWithObjects:[[NSMutableDictionary alloc]initWithObjectsAndKeys:@"",@"nombre", nil],[[NSMutableDictionary alloc]initWithObjectsAndKeys:@"",@"nombre", nil],[[NSMutableDictionary alloc]initWithObjectsAndKeys:@"",@"nombre", nil],[[NSMutableDictionary alloc]initWithObjectsAndKeys:@"",@"nombre", nil],[[NSMutableDictionary alloc]initWithObjectsAndKeys:@"",@"nombre", nil],[[NSMutableDictionary alloc]initWithObjectsAndKeys:@"",@"nombre", nil],[[NSMutableDictionary alloc]initWithObjectsAndKeys:@"",@"nombre", nil],[[NSMutableDictionary alloc]initWithObjectsAndKeys:@"",@"nombre", nil],[[NSMutableDictionary alloc]initWithObjectsAndKeys:@"",@"nombre", nil],[[NSMutableDictionary alloc]initWithObjectsAndKeys:@"",@"nombre", nil],[[NSMutableDictionary alloc]initWithObjectsAndKeys:@"",@"nombre", nil],[[NSMutableDictionary alloc]initWithObjectsAndKeys:@"",@"nombre", nil], nil];
    inventarioHeroe3=[[NSMutableArray alloc]initWithObjects:[[NSMutableDictionary alloc]initWithObjectsAndKeys:@"",@"nombre", nil],[[NSMutableDictionary alloc]initWithObjectsAndKeys:@"",@"nombre", nil],[[NSMutableDictionary alloc]initWithObjectsAndKeys:@"",@"nombre", nil],[[NSMutableDictionary alloc]initWithObjectsAndKeys:@"",@"nombre", nil],[[NSMutableDictionary alloc]initWithObjectsAndKeys:@"",@"nombre", nil],[[NSMutableDictionary alloc]initWithObjectsAndKeys:@"",@"nombre", nil],[[NSMutableDictionary alloc]initWithObjectsAndKeys:@"",@"nombre", nil],[[NSMutableDictionary alloc]initWithObjectsAndKeys:@"",@"nombre", nil],[[NSMutableDictionary alloc]initWithObjectsAndKeys:@"",@"nombre", nil],[[NSMutableDictionary alloc]initWithObjectsAndKeys:@"",@"nombre", nil],[[NSMutableDictionary alloc]initWithObjectsAndKeys:@"",@"nombre", nil],[[NSMutableDictionary alloc]initWithObjectsAndKeys:@"",@"nombre", nil], nil];
    inventarioHeroe4=[[NSMutableArray alloc]initWithObjects:[[NSMutableDictionary alloc]initWithObjectsAndKeys:@"",@"nombre", nil],[[NSMutableDictionary alloc]initWithObjectsAndKeys:@"",@"nombre", nil],[[NSMutableDictionary alloc]initWithObjectsAndKeys:@"",@"nombre", nil],[[NSMutableDictionary alloc]initWithObjectsAndKeys:@"",@"nombre", nil],[[NSMutableDictionary alloc]initWithObjectsAndKeys:@"",@"nombre", nil],[[NSMutableDictionary alloc]initWithObjectsAndKeys:@"",@"nombre", nil],[[NSMutableDictionary alloc]initWithObjectsAndKeys:@"",@"nombre", nil],[[NSMutableDictionary alloc]initWithObjectsAndKeys:@"",@"nombre", nil],[[NSMutableDictionary alloc]initWithObjectsAndKeys:@"",@"nombre", nil],[[NSMutableDictionary alloc]initWithObjectsAndKeys:@"",@"nombre", nil],[[NSMutableDictionary alloc]initWithObjectsAndKeys:@"",@"nombre", nil],[[NSMutableDictionary alloc]initWithObjectsAndKeys:@"",@"nombre", nil], nil];
    
    
    NSMutableArray *monstruos=[self guardarCartas:@"Enemigos"];
    minion1=[[monstruos objectAtIndex:0]mutableCopy];
    posicionMinion1X=9;
    posicionMinion1Y=1;
    minion2=[[monstruos objectAtIndex:1]mutableCopy];
    posicionMinion2X=10;
    posicionMinion2Y=0;
    minion3=[[monstruos objectAtIndex:2]mutableCopy];
    posicionMinion3X=10;
    posicionMinion3Y=4;
    minion4=[[monstruos objectAtIndex:3]mutableCopy];
    posicionMinion4X=12;
    posicionMinion4Y=0;
    minion5=[[monstruos objectAtIndex:4]mutableCopy];
    posicionMinion5X=12;
    posicionMinion5Y=4;
    boss=[[monstruos objectAtIndex:5]mutableCopy];
    posicionMinionBX=11;
    posicionMinionBY=1;

    NSMutableArray *heroes=[self guardarCartas:@"Heroes"];
    
    heroe1=[[heroes objectAtIndex:0]mutableCopy];
    heroe2=[[heroes objectAtIndex:1]mutableCopy];
    heroe3=[[heroes objectAtIndex:2]mutableCopy];
    heroe4=[[heroes objectAtIndex:3]mutableCopy];
    
    self.nombreHeroe.text=@"";
    self.vidaHeroe.text=@"";
    
    
    //Colocamos los cofres en sus lugar en el tablero
    [self.pasillo23 setBackgroundImage:[UIImage imageNamed:@"51X5cqcGS3L._SY450_.jpg" inBundle:[NSBundle bundleForClass:self.class] compatibleWithTraitCollection:nil] forState:UIControlStateNormal];
    [self.pasillo26 setBackgroundImage:[UIImage imageNamed:@"51X5cqcGS3L._SY450_.jpg" inBundle:[NSBundle bundleForClass:self.class] compatibleWithTraitCollection:nil] forState:UIControlStateNormal];
    
    
    //Creamos a los villanos y los colocamos en su respectivo lugar incial en el juego
    self.nombreMinion1.text=[minion1 valueForKey:@"nombre"];
    self.vidaMinion1.text=[NSString stringWithFormat:@"%@",[minion1 valueForKey:@"vida"]];
    self.nombreMinion1.adjustsFontSizeToFitWidth = YES;
    self.iconoVidaMinion1.image=[UIImage imageNamed:@"Heart.png" inBundle:[NSBundle bundleForClass:self.class] compatibleWithTraitCollection:nil];
    [self.pasillo211 setBackgroundImage:[UIImage imageNamed:@"zombie.png" inBundle:[NSBundle bundleForClass:self.class] compatibleWithTraitCollection:nil] forState:UIControlStateNormal];
    
    
    self.nombreMinion2.text=[minion2 valueForKey:@"nombre"];
    self.vidaMinion2.text=[NSString stringWithFormat:@"%@",[minion2 valueForKey:@"vida"]];
    self.nombreMinion2.adjustsFontSizeToFitWidth = YES;
    self.iconoVidaMinion2.image=[UIImage imageNamed:@"Heart.png" inBundle:[NSBundle bundleForClass:self.class] compatibleWithTraitCollection:nil];
    [self.salon1 setBackgroundImage:[UIImage imageNamed:@"zombie.png" inBundle:[NSBundle bundleForClass:self.class] compatibleWithTraitCollection:nil] forState:UIControlStateNormal];
    
    
    self.nombreMinion3.text=[minion3 valueForKey:@"nombre"];
    self.vidaMinion3.text=[NSString stringWithFormat:@"%@",[minion3 valueForKey:@"vida"]];
    self.nombreMinion3.adjustsFontSizeToFitWidth = YES;
    self.iconoVidaMinion3.image=[UIImage imageNamed:@"Heart.png" inBundle:[NSBundle bundleForClass:self.class] compatibleWithTraitCollection:nil];
    [self.salon4 setBackgroundImage:[UIImage imageNamed:@"zombie.png" inBundle:[NSBundle bundleForClass:self.class] compatibleWithTraitCollection:nil] forState:UIControlStateNormal];
    
    
    self.nombreMinion4.text=[minion4 valueForKey:@"nombre"];
    self.vidaMinion4.text=[NSString stringWithFormat:@"%@",[minion4 valueForKey:@"vida"]];
    self.nombreMinion4.adjustsFontSizeToFitWidth = YES;
    self.iconoVidaMinion4.image=[UIImage imageNamed:@"Heart.png" inBundle:[NSBundle bundleForClass:self.class] compatibleWithTraitCollection:nil];
    [self.salon9 setBackgroundImage:[UIImage imageNamed:@"zombie.png" inBundle:[NSBundle bundleForClass:self.class] compatibleWithTraitCollection:nil] forState:UIControlStateNormal];
    
    
    self.nombreMinion5.text=[minion5 valueForKey:@"nombre"];
    self.vidaMinion5.text=[NSString stringWithFormat:@"%@",[minion5 valueForKey:@"vida"]];
    self.nombreMinion5.adjustsFontSizeToFitWidth = YES;
    self.iconoVidaMinion5.image=[UIImage imageNamed:@"Heart.png" inBundle:[NSBundle bundleForClass:self.class] compatibleWithTraitCollection:nil];
    [self.salon12 setBackgroundImage:[UIImage imageNamed:@"zombie.png" inBundle:[NSBundle bundleForClass:self.class] compatibleWithTraitCollection:nil] forState:UIControlStateNormal];
    
    self.nombreBoss.text=[boss valueForKey:@"nombre"];
    self.vidaBoss.text=[NSString stringWithFormat:@"%@",[boss valueForKey:@"vida"]];
    self.nombreBoss.adjustsFontSizeToFitWidth = YES;
    self.iconoVidaBoss.image=[UIImage imageNamed:@"Heart.png" inBundle:[NSBundle bundleForClass:self.class] compatibleWithTraitCollection:nil];
    [self.salon6 setBackgroundImage:[UIImage imageNamed:@"zombie boss.jpg" inBundle:[NSBundle bundleForClass:self.class] compatibleWithTraitCollection:nil] forState:UIControlStateNormal];
}

-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    players=1;
    
    [self jugadores:players];
    
    //Colocamos el tablero en un array, en el que marcaremos los espacios con 0s, las paredes con X, y los enemigos con 2
    tablero=[[NSMutableArray alloc]initWithObjects:
             //PASILLO 1
             [[NSMutableArray alloc] initWithObjects:@"X",@"0",@"0",@"X", nil],
             [[NSMutableArray alloc]initWithObjects:@"0",@"0",@"0",@"0", nil],
             [[NSMutableArray alloc] initWithObjects:@"X",@"0",@"0",@"X", nil],
             [[NSMutableArray alloc]initWithObjects:@"0",@"0",@"0",@"0", nil],
             [[NSMutableArray alloc] initWithObjects:@"X",@"0",@"0",@"X", nil],
             //PASILLO 2
             [[NSMutableArray alloc] initWithObjects:@"X",@"0",@"0",@"X", nil],
             [[NSMutableArray alloc]initWithObjects:@"X",@"0",@"0",@"X", nil],
             [[NSMutableArray alloc] initWithObjects:@"X",@"0",@"0",@"X", nil],
             [[NSMutableArray alloc] initWithObjects:@"X",@"0",@"0",@"X", nil],
             [[NSMutableArray alloc] initWithObjects:@"X",@"2",@"0",@"X", nil],
             //SALÓN
             [[NSMutableArray alloc]initWithObjects:@"2",@"0",@"0",@"2", nil],
             [[NSMutableArray alloc]initWithObjects:@"0",@"2",@"0",@"0", nil],
             [[NSMutableArray alloc]initWithObjects:@"2",@"0",@"0",@"2", nil],
             //SALIDA
             [[NSMutableArray alloc] initWithObjects:@"X",@"0",@"0",@"X", nil],
             [[NSMutableArray alloc] initWithObjects:@"X",@"0",@"0",@"X", nil],nil];
    
    //Colocamos la posición del usuario en el tablero
    [[tablero objectAtIndex:0] replaceObjectAtIndex:1 withObject:@"1"];
    //Registramos las dos posiciones "x" e "y" del héroe, de forma que sepamos en qué fila y qué columna se encuentra del tablero.
    posicion1=0;
    posicion2=1;
    
    turnos=-1;
    
    [self turnosJuego];
}

-(void)turnosJuego{
    turnos=turnos+1;
    if(turnos%2==0){
        contadorAcciones=2;
        
        mostrandoInventario=false;
        self.botonTerminar.enabled=true;
        self.inventario.enabled=true;
        
        self.arriba.enabled=true;
        self.arriba.hidden=false;
        self.abajo.enabled=true;
        self.abajo.hidden=false;
        self.izquierda.enabled=true;
        self.izquierda.hidden=false;
        self.derecha.enabled=true;
        self.derecha.hidden=false;
        
        if([[player1 valueForKey:@"nombre"]isEqualToString:[heroe1 valueForKey:@"nombre"]]){[player1 setValue:[heroe1 valueForKey:@"movimiento"] forKey:@"movimiento"];}
        if([[player1 valueForKey:@"nombre"]isEqualToString:[heroe2 valueForKey:@"nombre"]]){[player1 setValue:[heroe2 valueForKey:@"movimiento"] forKey:@"movimiento"];}
        if([[player1 valueForKey:@"nombre"]isEqualToString:[heroe3 valueForKey:@"nombre"]]){[player1 setValue:[heroe3 valueForKey:@"movimiento"] forKey:@"movimiento"];}
        if([[player1 valueForKey:@"nombre"]isEqualToString:[heroe4 valueForKey:@"nombre"]]){[player1 setValue:[heroe4 valueForKey:@"movimiento"] forKey:@"movimiento"];}
    }
    else{
        self.inventario.enabled=false;
        self.boton1.enabled=false;
        self.boton1.hidden=true;
        self.boton2.enabled=false;
        self.boton2.hidden=true;
        self.boton3.enabled=false;
        self.boton3.hidden=true;
        self.boton4.enabled=false;
        self.boton4.hidden=true;
        self.boton5.enabled=false;
        self.boton5.hidden=true;
        self.boton6.enabled=false;
        self.boton6.hidden=true;
        self.boton7.enabled=false;
        self.boton7.hidden=true;
        self.boton8.enabled=false;
        self.boton8.hidden=true;
        self.boton9.enabled=false;
        self.boton9.hidden=true;
        self.boton10.enabled=false;
        self.boton10.hidden=true;
        self.boton11.enabled=false;
        self.boton11.hidden=true;
        self.boton12.enabled=false;
        self.boton12.hidden=true;
        //De esta forma, nos aseguramos de que el jugador no pueda usar objetos durante el turno rival, y que pueda ver todo el tablero sin que le tapen la visión los objetos de su inventario
        if(mostrandoInventario){mostrandoInventario=false;}
        
        self.arriba.enabled=false;
        self.arriba.hidden=true;
        self.abajo.enabled=false;
        self.abajo.hidden=true;
        self.izquierda.enabled=false;
        self.izquierda.hidden=true;
        self.derecha.enabled=false;
        self.derecha.hidden=true;
        
        //Deshabilitamos el botón terminar para evitar que el jugador pueda terminar el turno del rival
        self.botonTerminar.enabled=false;
        [self turnosJuego];
    }
}


-(NSMutableArray*)guardarCartas:(NSString*)nombre{
    NSString *filePath = [[NSBundle mainBundle] pathForResource:nombre ofType:@"json"];
    NSError *error = nil;
    NSData *JSONData = [NSData dataWithContentsOfFile:filePath options:NSDataReadingMappedIfSafe error:&error];
    id JSONObject = [NSJSONSerialization JSONObjectWithData:JSONData options:NSJSONReadingAllowFragments error:&error];
    NSMutableArray *arrResult = [[NSMutableArray alloc] init];
    NSMutableArray *arrayResult;
    for(int i=0;i<[JSONObject count];i++){
        arrayResult = [JSONObject objectAtIndex:i];
        [arrResult addObject:arrayResult];
    }
    return arrResult;
}

-(NSMutableArray*)resultadosDados:(NSMutableDictionary*)personaje{
    NSMutableArray *resultados1=[[NSMutableArray alloc]init];
    int dadosPersonaje1=[[personaje objectForKey:@"dados"]intValue]-1;
    int r=0;
    for(int i=0;i<dadosPersonaje1;i++){
        r=arc4random_uniform(6)+1;
        [resultados1 addObject:[NSString stringWithFormat:@"%i",r]];
    }
    
    NSArray *sorted = [[[resultados1 sortedArrayUsingSelector:@selector(compare:)] objectEnumerator] allObjects];
    resultados1=[sorted mutableCopy];
    return resultados1;
}

//Con este método realizaremos el sistema de combate y de cálculo de daño que se usa en el juego Dungeon Saga:The Dwarf King's Quest, es decir, ambos jugadores lanzan dados y se comparan los resultados, de orden ascendente a descendente según lo que se saca de los dados. Por cada dado cuyo valor sea superior al valor del dado del atacado, eso supone 1 golpe para los puntos de vida del personaje atacado.
-(void)pelea:(NSMutableDictionary*)personaje1 withPersonaje:(NSMutableDictionary*)personaje2{
    
    if([[personaje1 valueForKey:@"nombre"]isEqualToString:personajeFavorDioses]&&[[personaje2 objectForKey:@"vida"]intValue]>0){
        [personaje2 setValue:[NSString stringWithFormat:@"%i",[[personaje2 objectForKey:@"vida"]intValue]-1] forKey:@"vida"];
        personajeFavorDioses=@"";
        personajeFavorDioses=false;
        [heroe1 setValue:[NSString stringWithFormat:@"%i",[[heroe1 valueForKey:@"dados"]intValue]-1] forKey:@"dados"];
    }
    
    NSMutableArray *resultadosP1=[self resultadosDados:personaje1];
    NSMutableArray *resultadosP2=[self resultadosDados:personaje2];
    
    if([resultadosP1 count]!=[resultadosP2 count]){
        if([resultadosP1 count]<[resultadosP2 count]){
            for(int i=0;i<([resultadosP2 count]-[resultadosP1 count]);i++){
                [resultadosP1 addObject:[NSString stringWithFormat:@"%i",0]];
            }
        }
        else{
            for(int i=0;i<([resultadosP1 count]-[resultadosP2 count]);i++){
                [resultadosP2 addObject:[NSString stringWithFormat:@"%i",0]];
            }
        }
    }
    
    int hits=0;
    for(int i=0;i<[resultadosP1 count];i++){
        if([[resultadosP1 objectAtIndex:i]intValue]>[[resultadosP2 objectAtIndex:i]intValue]){
            if([[personaje2 objectForKey:@"vida"]intValue]>0){
                [personaje2 setValue:[NSString stringWithFormat:@"%i",[[personaje2 objectForKey:@"vida"]intValue]-1] forKey:@"vida"];
                hits=hits+1;
            }
        }
    }
    
    if([[personaje1 valueForKey:@"nombre"]isEqualToString:personajeChaman]&&[[personaje2 objectForKey:@"vida"]intValue]>0){
        [personaje2 setValue:[NSString stringWithFormat:@"%i",[[personaje2 objectForKey:@"vida"]intValue]-1] forKey:@"vida"];
        personajeChaman=@"";
        pocionChaman=false;
    }
    
    if([[personaje2 valueForKey:@"vida"]intValue]<=0){
        [self alertas:@"Mensaje" withMessage:[NSString stringWithFormat:@"%@ ha sido derrotado:",[personaje2 valueForKey:@"nombre"]]];
    }
    
    if([[personaje2 valueForKey:@"nombre"]isEqualToString:[player1 valueForKey:@"nombre"]]){
        player1=[personaje2 mutableCopy];
        if([[player1 valueForKey:@"vida"]intValue]<=0){
            [player1 setValue:@"0" forKey:@"vida"];
            self.heroe1Img.enabled=false;
            self.heroe1Img.hidden=true;
            self.iconoVidaHeroe1.image=[UIImage imageNamed:@"HeartVencido.png" inBundle:[NSBundle bundleForClass:self.class] compatibleWithTraitCollection:nil];
            [self eliminarHeroe:[player1 valueForKey:@"nombre"]];
        }
        self.vidaHeroe.text=[player1 valueForKey:@"vida"];
    }
    
    if([[personaje2 valueForKey:@"nombre"]isEqualToString:[player2 valueForKey:@"nombre"]]){
        player2=[personaje2 mutableCopy];
        if([[player2 valueForKey:@"vida"]intValue]<=0){
            [player2 setValue:@"0" forKey:@"vida"];
            self.heroe2Img.enabled=false;
            self.heroe2Img.hidden=true;
            self.iconoVidaHeroe2.image=[UIImage imageNamed:@"HeartVencido.png" inBundle:[NSBundle bundleForClass:self.class] compatibleWithTraitCollection:nil];
            [self eliminarHeroe:[player2 valueForKey:@"nombre"]];
        }
        self.vidaHeroe.text=[player2 valueForKey:@"vida"];
    }
    
    if([[personaje2 valueForKey:@"nombre"]isEqualToString:[player3 valueForKey:@"nombre"]]){
        player3=[personaje2 mutableCopy];
        if([[player3 valueForKey:@"vida"]intValue]<=0){
            [player3 setValue:@"0" forKey:@"vida"];
            self.heroe3Img.enabled=false;
            self.heroe3Img.hidden=true;
            self.iconoVidaHeroe3.image=[UIImage imageNamed:@"HeartVencido.png" inBundle:[NSBundle bundleForClass:self.class] compatibleWithTraitCollection:nil];
            [self eliminarHeroe:[player3 valueForKey:@"nombre"]];
        }
        self.vidaHeroe.text=[player3 valueForKey:@"vida"];
    }
    
    if([[personaje2 valueForKey:@"nombre"]isEqualToString:[player4 valueForKey:@"nombre"]]){
        player4=[personaje2 mutableCopy];
        if([[player4 valueForKey:@"vida"]intValue]<=0){
            [player4 setValue:@"0" forKey:@"vida"];
            self.heroe4Img.enabled=false;
            self.heroe4Img.hidden=true;
            self.iconoVidaHeroe4.image=[UIImage imageNamed:@"HeartVencido.png" inBundle:[NSBundle bundleForClass:self.class] compatibleWithTraitCollection:nil];
            [self eliminarHeroe:[player4 valueForKey:@"nombre"]];
        }
        self.vidaHeroe.text=[player4 valueForKey:@"vida"];
    }
    
    if([[personaje2 valueForKey:@"nombre"]isEqualToString:[minion1 valueForKey:@"nombre"]]){
        personaje2=[minion1 mutableCopy];
        if([[minion1 valueForKey:@"vida"]intValue]<=0){
            [minion1 setValue:@"0" forKey:@"vida"];
            self.minion1Img.enabled=false;
            self.minion1Img.hidden=true;
            self.iconoVidaMinion1.image=[UIImage imageNamed:@"HeartVencido.png" inBundle:[NSBundle bundleForClass:self.class] compatibleWithTraitCollection:nil];
            [self eliminarDelTablero:@"minion1" inPosicion:posicionMinion1X yPosicion:posicionMinion1Y yHeroe:[personaje1 valueForKey:@"nombre"]];
        }
        self.vidaMinion1.text=[minion1 valueForKey:@"vida"];
    }
    
    if([[personaje2 valueForKey:@"nombre"]isEqualToString:[minion2 valueForKey:@"nombre"]]){
        personaje2=[minion2 mutableCopy];
        if([[minion2 valueForKey:@"vida"]intValue]<=0){
            [minion2 setValue:@"0" forKey:@"vida"];
            self.minion2Img.enabled=false;
            self.minion2Img.hidden=true;
            self.iconoVidaMinion2.image=[UIImage imageNamed:@"HeartVencido.png" inBundle:[NSBundle bundleForClass:self.class] compatibleWithTraitCollection:nil];
            [self eliminarDelTablero:@"minion2" inPosicion:posicionMinion2X yPosicion:posicionMinion2Y yHeroe:[personaje1 valueForKey:@"nombre"]];
        }
        self.vidaMinion2.text=[minion2 valueForKey:@"vida"];
    }
    
    if([[personaje2 valueForKey:@"nombre"]isEqualToString:[minion3 valueForKey:@"nombre"]]){
        personaje2=[minion3 mutableCopy];
        if([[minion3 valueForKey:@"vida"]intValue]<=0){
            [minion3 setValue:@"0" forKey:@"vida"];
            self.minion3Img.enabled=false;
            self.minion3Img.hidden=true;
            self.iconoVidaMinion3.image=[UIImage imageNamed:@"HeartVencido.png" inBundle:[NSBundle bundleForClass:self.class] compatibleWithTraitCollection:nil];
            [self eliminarDelTablero:@"minion3" inPosicion:posicionMinion3X yPosicion:posicionMinion3Y yHeroe:[personaje1 valueForKey:@"nombre"]];
        }
        self.vidaMinion3.text=[minion3 valueForKey:@"vida"];
    }
    
    if([[personaje2 valueForKey:@"nombre"]isEqualToString:[minion4 valueForKey:@"nombre"]]){
        personaje2=[minion4 mutableCopy];
        if([[minion4 valueForKey:@"vida"]intValue]<=0){
            [minion4 setValue:@"0" forKey:@"vida"];
            self.minion4Img.enabled=false;
            self.minion4Img.hidden=true;
            self.iconoVidaMinion4.image=[UIImage imageNamed:@"HeartVencido.png" inBundle:[NSBundle bundleForClass:self.class] compatibleWithTraitCollection:nil];
            [self eliminarDelTablero:@"minion4" inPosicion:posicionMinion4X yPosicion:posicionMinion4Y yHeroe:[personaje1 valueForKey:@"nombre"]];
        }
        self.vidaMinion4.text=[minion4 valueForKey:@"vida"];
    }
    
    if([[personaje2 valueForKey:@"nombre"]isEqualToString:[minion5 valueForKey:@"nombre"]]){
        personaje2=[minion5 mutableCopy];
        if([[minion5 valueForKey:@"vida"]intValue]<=0){
            [minion5 setValue:@"0" forKey:@"vida"];
            self.minion5Img.enabled=false;
            self.minion5Img.hidden=true;
            self.iconoVidaMinion5.image=[UIImage imageNamed:@"HeartVencido.png" inBundle:[NSBundle bundleForClass:self.class] compatibleWithTraitCollection:nil];
            [self eliminarDelTablero:@"minion5" inPosicion:posicionMinion5X yPosicion:posicionMinion5Y yHeroe:[personaje1 valueForKey:@"nombre"]];
        }
        self.vidaMinion5.text=[minion5 valueForKey:@"vida"];
    }
    
    if([[personaje2 valueForKey:@"nombre"]isEqualToString:[boss valueForKey:@"nombre"]]){
        personaje2=[boss mutableCopy];
        if([[boss valueForKey:@"vida"]intValue]<=0){
            [boss setValue:@"0" forKey:@"vida"];
            self.bossImg.enabled=false;
            self.bossImg.hidden=true;
            self.iconoVidaBoss.image=[UIImage imageNamed:@"HeartVencido.png" inBundle:[NSBundle bundleForClass:self.class] compatibleWithTraitCollection:nil];
            [self eliminarDelTablero:@"boss" inPosicion:posicionMinionBX yPosicion:posicionMinionBY yHeroe:[personaje1 valueForKey:@"nombre"]];
        }
        self.vidaBoss.text=[boss valueForKey:@"vida"];
    }
}

//Con este método, eliminamos a los monstruos que tienen 0 puntos de vida
-(void)eliminarDelTablero:(NSString*)personaje inPosicion:(int)posicionx yPosicion:(int)posiciony yHeroe:(NSString*)heroe{
    [[tablero objectAtIndex:posicionx] replaceObjectAtIndex:posiciony withObject:@"0"];
    
    //Premio por abrir los cofres: 5 monedas. Premio por cargarse a un monstruo: 5 monedas. Premio por cargarse al jefe zombi:10 puntos.
    if([[player1 valueForKey:@"nombre"]isEqualToString:heroe]){
        if([personaje isEqualToString:@"minion1"]||[personaje isEqualToString:@"minion2"]||[personaje isEqualToString:@"minion3"]||[personaje isEqualToString:@"minion4"]||[personaje isEqualToString:@"minion5"]){
            [player1 setValue:[NSString stringWithFormat:@"%i",[[player1 valueForKey:@"monedas de oro"]intValue]+5] forKey:@"monedas de oro"];
        }else if([personaje isEqualToString:@"boss"]){
            [player1 setValue:[NSString stringWithFormat:@"%i",[[player1 valueForKey:@"monedas de oro"]intValue]+10] forKey:@"monedas de oro"];
        }
    }
    
    if([[player2 valueForKey:@"nombre"]isEqualToString:heroe]){
        if([personaje isEqualToString:@"minion1"]||[personaje isEqualToString:@"minion2"]||[personaje isEqualToString:@"minion3"]||[personaje isEqualToString:@"minion4"]||[personaje isEqualToString:@"minion5"]){
            [player2 setValue:[NSString stringWithFormat:@"%i",[[player2 valueForKey:@"monedas de oro"]intValue]+5] forKey:@"monedas de oro"];
        }else if([personaje isEqualToString:@"boss"]){
            [player2 setValue:[NSString stringWithFormat:@"%i",[[player2 valueForKey:@"monedas de oro"]intValue]+10] forKey:@"monedas de oro"];
        }
    }
    
    if([[player3 valueForKey:@"nombre"]isEqualToString:heroe]){
        if([personaje isEqualToString:@"minion1"]||[personaje isEqualToString:@"minion2"]||[personaje isEqualToString:@"minion3"]||[personaje isEqualToString:@"minion4"]||[personaje isEqualToString:@"minion5"]){
            [player3 setValue:[NSString stringWithFormat:@"%i",[[player3 valueForKey:@"monedas de oro"]intValue]+5] forKey:@"monedas de oro"];
        }else if([personaje isEqualToString:@"boss"]){
            [player3 setValue:[NSString stringWithFormat:@"%i",[[player3 valueForKey:@"monedas de oro"]intValue]+10] forKey:@"monedas de oro"];
        }
    }
    
    if([[player4 valueForKey:@"nombre"]isEqualToString:heroe]){
        if([personaje isEqualToString:@"minion1"]||[personaje isEqualToString:@"minion2"]||[personaje isEqualToString:@"minion3"]||[personaje isEqualToString:@"minion4"]||[personaje isEqualToString:@"minion5"]){
            [player4 setValue:[NSString stringWithFormat:@"%i",[[player4 valueForKey:@"monedas de oro"]intValue]+5] forKey:@"monedas de oro"];
        }else if([personaje isEqualToString:@"boss"]){
            [player4 setValue:[NSString stringWithFormat:@"%i",[[player4 valueForKey:@"monedas de oro"]intValue]+10] forKey:@"monedas de oro"];
        }
    }
    
    if([personaje isEqualToString:@"minion1"]){
        posicionMinion1X=0;
        posicionMinion1Y=0;
    }else if([personaje isEqualToString:@"minion2"]){
        posicionMinion2X=0;
        posicionMinion2Y=0;
    }else if([personaje isEqualToString:@"minion3"]){
        posicionMinion3X=0;
        posicionMinion3Y=0;
    }else if([personaje isEqualToString:@"minion4"]){
        posicionMinion4X=0;
        posicionMinion4Y=0;
    }else if([personaje isEqualToString:@"minion5"]){
        posicionMinion5X=0;
        posicionMinion5Y=0;
    }else if([personaje isEqualToString:@"boss"]){
        posicionMinionBX=0;
        posicionMinionBY=0;
    }
    
    //Eliminamos al monstruo de su posición actual
    switch (posicionx) {
        //PASILLO 2
        case 5:switch (posiciony) {
                case 1:[self.pasillo21 setBackgroundImage:false forState:UIControlStateNormal];break;
                case 2:[self.pasillo22 setBackgroundImage:false forState:UIControlStateNormal];break;
            }break;
            
        case 6:switch (posiciony) {
                case 0:[self.pasillo23 setBackgroundImage:false forState:UIControlStateNormal];break;
                case 1:[self.pasillo24 setBackgroundImage:false forState:UIControlStateNormal];break;
                case 2:[self.pasillo25 setBackgroundImage:false forState:UIControlStateNormal];break;
                case 3:[self.pasillo26 setBackgroundImage:false forState:UIControlStateNormal];break;
            }break;
            
        case 7:switch (posiciony) {
                case 1:[self.pasillo27 setBackgroundImage:false forState:UIControlStateNormal];break;
                case 2:[self.pasillo28 setBackgroundImage:false forState:UIControlStateNormal];break;
            }break;
            
        case 8:switch (posiciony) {
                case 1:[self.pasillo29 setBackgroundImage:false forState:UIControlStateNormal];break;
                case 2:[self.pasillo210 setBackgroundImage:false forState:UIControlStateNormal];break;
            }break;
            
        case 9:switch (posiciony) {
                case 1:[self.pasillo211 setBackgroundImage:false forState:UIControlStateNormal];break;
                case 2:[self.pasillo212 setBackgroundImage:false forState:UIControlStateNormal];break;
            }break;
            
        //SALÓN
        case 10:switch (posiciony) {
                case 0:[self.salon1 setBackgroundImage:false forState:UIControlStateNormal];break;
                case 1:[self.salon2 setBackgroundImage:false forState:UIControlStateNormal];break;
                case 2:[self.salon3 setBackgroundImage:false forState:UIControlStateNormal];break;
                case 3:[self.salon4 setBackgroundImage:false forState:UIControlStateNormal];break;
            }break;
            
        case 11:switch (posiciony) {
                case 0:[self.salon5 setBackgroundImage:false forState:UIControlStateNormal];break;
                case 1:[self.salon6 setBackgroundImage:false forState:UIControlStateNormal];break;
                case 2:[self.salon7 setBackgroundImage:false forState:UIControlStateNormal];break;
                case 3:[self.salon8 setBackgroundImage:false forState:UIControlStateNormal];break;
            }break;
            
        case 12:switch (posiciony) {
                case 0:[self.salon9 setBackgroundImage:false forState:UIControlStateNormal];break;
                case 1:[self.salon10 setBackgroundImage:false forState:UIControlStateNormal];break;
                case 2:[self.salon11 setBackgroundImage:false forState:UIControlStateNormal];break;
                case 3:[self.salon12 setBackgroundImage:false forState:UIControlStateNormal];break;
            }break;
            
        //SALIDA
        case 13:switch (posiciony) {
                case 1:[self.salida1 setBackgroundImage:false forState:UIControlStateNormal];break;
                case 2:[self.salida2 setBackgroundImage:false forState:UIControlStateNormal];break;
            }break;
            
        case 14:switch (posiciony) {
                case 1:[self.salida3 setBackgroundImage:false forState:UIControlStateNormal];break;
                case 2:[self.salida4 setBackgroundImage:false forState:UIControlStateNormal];break;
            }break;
    }
}

//Con este método, eliminamos a los héroes que tienen 0 puntos de vida. Si todos acaban muertos, el juego terminará
-(void)eliminarHeroe:(NSString*)personaje{
    [[tablero objectAtIndex:posicion1] replaceObjectAtIndex:posicion2 withObject:@"0"];

    
    //Eliminamos al héroe de su posición actual
    switch (posicion1) {
        //PASILLO 2
        case 5:switch (posicion2) {
            case 1: self.pasillo21.backgroundColor=nil;break;
            case 2:self.pasillo22.backgroundColor=nil;break;
        }break;
            
        case 6:switch (posicion2) {
            case 0:self.pasillo23.backgroundColor=nil;break;
            case 1:self.pasillo24.backgroundColor=nil;break;
            case 2:self.pasillo25.backgroundColor=nil;break;
            case 3:self.pasillo26.backgroundColor=nil;break;
        }break;
            
        case 7:switch (posicion2) {
            case 1:self.pasillo27.backgroundColor=nil;break;
            case 2:self.pasillo28.backgroundColor=nil;break;
        }break;
            
        case 8:switch (posicion2) {
            case 1:self.pasillo29.backgroundColor=nil;break;
            case 2:self.pasillo210.backgroundColor=nil;break;
        }break;
            
        case 9:switch (posicion2) {
            case 1:self.pasillo211.backgroundColor=nil;break;
            case 2:self.pasillo212.backgroundColor=nil;break;
        }break;
            
        //SALÓN
        case 10:switch (posicion2) {
            case 0:self.salon1.backgroundColor=nil;break;
            case 1:self.salon2.backgroundColor=nil;break;
            case 2:self.salon3.backgroundColor=nil;break;
            case 3:self.salon4.backgroundColor=nil;break;
        }break;
            
        case 11:switch (posicion2) {
            case 0:self.salon5.backgroundColor=nil;break;
            case 1:self.salon6.backgroundColor=nil;break;
            case 2:self.salon7.backgroundColor=nil;break;
            case 3:self.salon8.backgroundColor=nil;break;
        }break;
            
        case 12:switch (posicion2) {
            case 0:self.salon9.backgroundColor=nil;break;
            case 1:self.salon10.backgroundColor=nil;break;
            case 2:self.salon11.backgroundColor=nil;break;
            case 3:self.salon12.backgroundColor=nil;break;
        }break;
            
        //SALIDA
        case 13:switch (posicion2) {
            case 1:self.salida1.backgroundColor=nil;break;
            case 2:self.salida2.backgroundColor=nil;break;
        }break;
            
        case 14:switch (posicion2) {
            case 1:self.salida3.backgroundColor=nil;break;
            case 2:self.salida4.backgroundColor=nil;break;
        }break;
    }
    
    posicion1=0;
    posicion2=0;
    [self finDelJuego];
}


//Creamos un método que nos mostrará una alerta por pantalla
- (void)alertas:(NSString*)mensaje1 withMessage:(NSString*)mensaje2{
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:mensaje1 message:mensaje2 preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction* action1 = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action){[self dismissViewControllerAnimated:YES completion:^{}];}];
    [alert addAction:action1];
    [self presentViewController:alert animated:YES completion:nil];
}

//Si el juego termina, bloquearemos los botones del inventario, de movimiento, y de fin de turno, de forma que el jugador, pierda o gane, no pueda moverse
-(void)finDelJuego{
    self.botonTerminar.enabled=false;
    self.botonTerminar.hidden=true;
    self.arriba.enabled=false;
    self.abajo.enabled=false;
    self.izquierda.enabled=false;
    self.derecha.enabled=false;
    self.inventario.enabled=false;
    self.boton1.enabled=false;
    self.boton1.hidden=true;
    self.boton2.enabled=false;
    self.boton2.hidden=true;
    self.boton3.enabled=false;
    self.boton3.hidden=true;
    self.boton4.enabled=false;
    self.boton4.hidden=true;
    self.boton5.enabled=false;
    self.boton5.hidden=true;
    self.boton6.enabled=false;
    self.boton6.hidden=true;
    self.boton7.enabled=false;
    self.boton7.hidden=true;
    self.boton8.enabled=false;
    self.boton8.hidden=true;
    self.boton9.enabled=false;
    self.boton9.hidden=true;
    self.boton10.enabled=false;
    self.boton10.hidden=true;
    self.boton11.enabled=false;
    self.boton11.hidden=true;
    self.boton12.enabled=false;
    self.boton12.hidden=true;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
//Si la posición del array no está vacía (no tiene el valor por defecto dado antes), permitiremos usar ese objeto. Si el objeto se tratase de la Poción de Vida, no lo usaremos si ya temenos todos los puntos de vida
- (IBAction)usoObjeto1:(id)sender {
    if(self.boton1.isEnabled&&![[[inventarioHeroe1 objectAtIndex:0]valueForKey:@"nombre"]isEqualToString:@""]){
        if([[[inventarioHeroe1 objectAtIndex:0]valueForKey:@"nombre"]isEqualToString:@"Poción de Vida"]&&[[player1 valueForKey:@"vida"]intValue]<5){
            [self efectosObjetos:[[inventarioHeroe1 objectAtIndex:0]valueForKey:@"nombre"]];
            [self.boton1 setBackgroundImage:nil forState:UIControlStateNormal];
            self.boton1.backgroundColor=[UIColor greenColor];
        }else if(![[[inventarioHeroe1 objectAtIndex:0]valueForKey:@"nombre"]isEqualToString:@"Poción de Vida"]){
            [self efectosObjetos:[[inventarioHeroe1 objectAtIndex:0]valueForKey:@"nombre"]];
            [self.boton1 setBackgroundImage:nil forState:UIControlStateNormal];
            self.boton1.backgroundColor=[UIColor greenColor];
        }
        [[inventarioHeroe1 objectAtIndex:0] setValue:@"" forKey:@"nombre"];
    }
}

- (IBAction)usoObjeto2:(id)sender {
    if(self.boton2.isEnabled&&![[[inventarioHeroe1 objectAtIndex:1]valueForKey:@"nombre"]isEqualToString:@""]){
        [self efectosObjetos:[[inventarioHeroe1 objectAtIndex:1]valueForKey:@"nombre"]];
        if([[[inventarioHeroe1 objectAtIndex:1]valueForKey:@"nombre"]isEqualToString:@"Poción de Vida"]&&[[player1 valueForKey:@"vida"]intValue]<5){
            [self.boton2 setBackgroundImage:nil forState:UIControlStateNormal];
            self.boton2.backgroundColor=[UIColor greenColor];
        }else if(![[[inventarioHeroe1 objectAtIndex:1]valueForKey:@"nombre"]isEqualToString:@"Poción de Vida"]){
            [self.boton2 setBackgroundImage:nil forState:UIControlStateNormal];
            self.boton2.backgroundColor=[UIColor greenColor];
        }
    }
}

- (IBAction)usoObjeto3:(id)sender {
    if(self.boton3.isEnabled&&![[[inventarioHeroe1 objectAtIndex:2]valueForKey:@"nombre"]isEqualToString:@""]){
        [self efectosObjetos:[[inventarioHeroe1 objectAtIndex:2]valueForKey:@"nombre"]];
        if([[[inventarioHeroe1 objectAtIndex:2]valueForKey:@"nombre"]isEqualToString:@"Poción de Vida"]&&[[player1 valueForKey:@"vida"]intValue]<5){
            [self.boton3 setBackgroundImage:nil forState:UIControlStateNormal];
            self.boton3.backgroundColor=[UIColor greenColor];
        }else if(![[[inventarioHeroe1 objectAtIndex:2]valueForKey:@"nombre"]isEqualToString:@"Poción de Vida"]){
            [self.boton3 setBackgroundImage:nil forState:UIControlStateNormal];
            self.boton3.backgroundColor=[UIColor greenColor];
        }
    }
}

- (IBAction)usoObjeto4:(id)sender {
    if(self.boton4.isEnabled&&![[[inventarioHeroe1 objectAtIndex:3]valueForKey:@"nombre"]isEqualToString:@""]){
        [self efectosObjetos:[[inventarioHeroe1 objectAtIndex:3]valueForKey:@"nombre"]];
        if([[[inventarioHeroe1 objectAtIndex:3]valueForKey:@"nombre"]isEqualToString:@"Poción de Vida"]&&[[player1 valueForKey:@"vida"]intValue]<5){
            [self.boton4 setBackgroundImage:nil forState:UIControlStateNormal];
            self.boton4.backgroundColor=[UIColor greenColor];
        }else if(![[[inventarioHeroe1 objectAtIndex:3]valueForKey:@"nombre"]isEqualToString:@"Poción de Vida"]){
            [self.boton4 setBackgroundImage:nil forState:UIControlStateNormal];
            self.boton4.backgroundColor=[UIColor greenColor];
        }
    }
}

- (IBAction)usoObjeto5:(id)sender {
    if(self.boton5.isEnabled&&![[[inventarioHeroe1 objectAtIndex:4]valueForKey:@"nombre"]isEqualToString:@""]){
        [self efectosObjetos:[[inventarioHeroe1 objectAtIndex:4]valueForKey:@"nombre"]];
        if([[[inventarioHeroe1 objectAtIndex:4]valueForKey:@"nombre"]isEqualToString:@"Poción de Vida"]&&[[player1 valueForKey:@"vida"]intValue]<5){
            [self.boton5 setBackgroundImage:nil forState:UIControlStateNormal];
            self.boton5.backgroundColor=[UIColor greenColor];
        }else if(![[[inventarioHeroe1 objectAtIndex:4]valueForKey:@"nombre"]isEqualToString:@"Poción de Vida"]){
            [self.boton5 setBackgroundImage:nil forState:UIControlStateNormal];
            self.boton5.backgroundColor=[UIColor greenColor];
        }
    }
}

- (IBAction)usoObjeto6:(id)sender {
    if(self.boton6.isEnabled&&![[[inventarioHeroe1 objectAtIndex:5]valueForKey:@"nombre"]isEqualToString:@""]){
        [self efectosObjetos:[[inventarioHeroe1 objectAtIndex:5]valueForKey:@"nombre"]];
        if([[[inventarioHeroe1 objectAtIndex:5]valueForKey:@"nombre"]isEqualToString:@"Poción de Vida"]&&[[player1 valueForKey:@"vida"]intValue]<5){
            [self.boton6 setBackgroundImage:nil forState:UIControlStateNormal];
            self.boton6.backgroundColor=[UIColor greenColor];
        }else if(![[[inventarioHeroe1 objectAtIndex:5]valueForKey:@"nombre"]isEqualToString:@"Poción de Vida"]){
            [self.boton6 setBackgroundImage:nil forState:UIControlStateNormal];
            self.boton6.backgroundColor=[UIColor greenColor];
        }
    }
}

- (IBAction)usoObjeto7:(id)sender {
    if(self.boton7.isEnabled&&![[[inventarioHeroe1 objectAtIndex:6]valueForKey:@"nombre"]isEqualToString:@""]){
        [self efectosObjetos:[[inventarioHeroe1 objectAtIndex:6]valueForKey:@"nombre"]];
        if([[[inventarioHeroe1 objectAtIndex:6]valueForKey:@"nombre"]isEqualToString:@"Poción de Vida"]&&[[player1 valueForKey:@"vida"]intValue]<5){
            [self.boton7 setBackgroundImage:nil forState:UIControlStateNormal];
            self.boton7.backgroundColor=[UIColor greenColor];
        }else if(![[[inventarioHeroe1 objectAtIndex:6]valueForKey:@"nombre"]isEqualToString:@"Poción de Vida"]){
            [self.boton7 setBackgroundImage:nil forState:UIControlStateNormal];
            self.boton7.backgroundColor=[UIColor greenColor];
        }
    }
}

- (IBAction)usoObjeto8:(id)sender {
    if(self.boton8.isEnabled&&![[[inventarioHeroe1 objectAtIndex:7]valueForKey:@"nombre"]isEqualToString:@""]){
        [self efectosObjetos:[[inventarioHeroe1 objectAtIndex:7]valueForKey:@"nombre"]];
        if([[[inventarioHeroe1 objectAtIndex:7]valueForKey:@"nombre"]isEqualToString:@"Poción de Vida"]&&[[player1 valueForKey:@"vida"]intValue]<5){
            [self.boton8 setBackgroundImage:nil forState:UIControlStateNormal];
            self.boton8.backgroundColor=[UIColor greenColor];
        }else if(![[[inventarioHeroe1 objectAtIndex:7]valueForKey:@"nombre"]isEqualToString:@"Poción de Vida"]){
            [self.boton8 setBackgroundImage:nil forState:UIControlStateNormal];
            self.boton8.backgroundColor=[UIColor greenColor];
        }
    }
}

- (IBAction)usoObjeto9:(id)sender {
    if(self.boton9.isEnabled&&[[[inventarioHeroe1 objectAtIndex:8]valueForKey:@"nombre"]isEqualToString:@""]){
        [self efectosObjetos:[[inventarioHeroe1 objectAtIndex:8]valueForKey:@"nombre"]];
        if([[[inventarioHeroe1 objectAtIndex:8]valueForKey:@"nombre"]isEqualToString:@"Poción de Vida"]&&[[player1 valueForKey:@"vida"]intValue]<5){
            [self.boton9 setBackgroundImage:nil forState:UIControlStateNormal];
            self.boton9.backgroundColor=[UIColor greenColor];
        }else if(![[[inventarioHeroe1 objectAtIndex:8]valueForKey:@"nombre"]isEqualToString:@"Poción de Vida"]){
            [self.boton9 setBackgroundImage:nil forState:UIControlStateNormal];
            self.boton9.backgroundColor=[UIColor greenColor];
        }
    }
}

- (IBAction)usoObjeto10:(id)sender {
    if(self.boton10.isEnabled&&[[[inventarioHeroe1 objectAtIndex:9]valueForKey:@"nombre"]isEqualToString:@""]){
        [self efectosObjetos:[[inventarioHeroe1 objectAtIndex:9]valueForKey:@"nombre"]];
        if([[[inventarioHeroe1 objectAtIndex:9]valueForKey:@"nombre"]isEqualToString:@"Poción de Vida"]&&[[player1 valueForKey:@"vida"]intValue]<5){
            [self.boton10 setBackgroundImage:nil forState:UIControlStateNormal];
            self.boton10.backgroundColor=[UIColor greenColor];
        }else if(![[[inventarioHeroe1 objectAtIndex:9]valueForKey:@"nombre"]isEqualToString:@"Poción de Vida"]){
            [self.boton10 setBackgroundImage:nil forState:UIControlStateNormal];
            self.boton10.backgroundColor=[UIColor greenColor];
        }
    }
}

- (IBAction)usoObjeto11:(id)sender {
    if(self.boton11.isEnabled&&[[[inventarioHeroe1 objectAtIndex:10]valueForKey:@"nombre"]isEqualToString:@""]){
        [self efectosObjetos:[[inventarioHeroe1 objectAtIndex:10]valueForKey:@"nombre"]];
        if([[[inventarioHeroe1 objectAtIndex:10]valueForKey:@"nombre"]isEqualToString:@"Poción de Vida"]&&[[player1 valueForKey:@"vida"]intValue]<5){
            [self.boton11 setBackgroundImage:nil forState:UIControlStateNormal];
            self.boton11.backgroundColor=[UIColor greenColor];
        }else if(![[[inventarioHeroe1 objectAtIndex:10]valueForKey:@"nombre"]isEqualToString:@"Poción de Vida"]){
            [self.boton11 setBackgroundImage:nil forState:UIControlStateNormal];
            self.boton11.backgroundColor=[UIColor greenColor];
        }
    }
}

- (IBAction)usoObjeto12:(id)sender {
    if(self.boton12.isEnabled&&[[[inventarioHeroe1 objectAtIndex:11]valueForKey:@"nombre"]isEqualToString:@""]){
        [self efectosObjetos:[[inventarioHeroe1 objectAtIndex:11]valueForKey:@"nombre"]];
        if([[[inventarioHeroe1 objectAtIndex:11]valueForKey:@"nombre"]isEqualToString:@"Poción de Vida"]&&[[player1 valueForKey:@"vida"]intValue]<5){
            [self.boton12 setBackgroundImage:nil forState:UIControlStateNormal];
            self.boton12.backgroundColor=[UIColor greenColor];
        }else if(![[[inventarioHeroe1 objectAtIndex:11]valueForKey:@"nombre"]isEqualToString:@"Poción de Vida"]){
            [self.boton12 setBackgroundImage:nil forState:UIControlStateNormal];
            self.boton12.backgroundColor=[UIColor greenColor];
        }
    }
}

-(void)efectosObjetos:(NSString*)objeto{
    if([objeto isEqualToString:@"Poción de Vida"]){
        if([[player1 valueForKey:@"vida"]intValue]<5){
            [player1 setValue:[NSString stringWithFormat:@"%i",[[player1 valueForKey:@"vida"]intValue]+1] forKey:@"vida"];
            self.vidaHeroe.text=[player1 valueForKey:@"vida"];
        }
    }
    
    if([objeto isEqualToString:@"Poción del Chamán"]){
        pocionChaman=true;
        personajeChaman=[player1 valueForKey:@"nombre"];
    }
    
    if([objeto isEqualToString:@"Favor de los Dioses"]){
        favordeDioses=true;
        personajeFavorDioses=[player1 valueForKey:@"nombre"];
        [player1 setValue:[NSString stringWithFormat:@"%i",[[player1 valueForKey:@"dados"]intValue]+1] forKey:@"dados"];
    }
}


- (IBAction)verinventario:(id)sender {
    //Si el inventario no está abierto, lo mostraremos, e impediremos que el jugador pueda utilizar los botones de dirección
    if(mostrandoInventario==false){
        self.boton1.enabled=true;
        self.boton1.hidden=false;
        self.boton2.enabled=true;
        self.boton2.hidden=false;
        self.boton3.enabled=true;
        self.boton3.hidden=false;
        self.boton4.enabled=true;
        self.boton4.hidden=false;
        self.boton5.enabled=true;
        self.boton5.hidden=false;
        self.boton6.enabled=true;
        self.boton6.hidden=false;
        self.boton7.enabled=true;
        self.boton7.hidden=false;
        self.boton8.enabled=true;
        self.boton8.hidden=false;
        self.boton9.enabled=true;
        self.boton9.hidden=false;
        self.boton10.enabled=true;
        self.boton10.hidden=false;
        self.boton11.enabled=true;
        self.boton11.hidden=false;
        self.boton12.enabled=true;
        self.boton12.hidden=false;
        mostrandoInventario=true;
        
        self.arriba.enabled=false;
        self.arriba.hidden=true;
        self.abajo.enabled=false;
        self.abajo.hidden=true;
        self.izquierda.enabled=false;
        self.izquierda.hidden=true;
        self.derecha.enabled=false;
        self.derecha.hidden=true;
    }
    else{
        self.boton1.enabled=false;
        self.boton1.hidden=true;
        self.boton2.enabled=false;
        self.boton2.hidden=true;
        self.boton3.enabled=false;
        self.boton3.hidden=true;
        self.boton4.enabled=false;
        self.boton4.hidden=true;
        self.boton5.enabled=false;
        self.boton5.hidden=true;
        self.boton6.enabled=false;
        self.boton6.hidden=true;
        self.boton7.enabled=false;
        self.boton7.hidden=true;
        self.boton8.enabled=false;
        self.boton8.hidden=true;
        self.boton9.enabled=false;
        self.boton9.hidden=true;
        self.boton10.enabled=false;
        self.boton10.hidden=true;
        self.boton11.enabled=false;
        self.boton11.hidden=true;
        self.boton12.enabled=false;
        self.boton12.hidden=true;
        mostrandoInventario=false;
        
        self.arriba.enabled=true;
        self.arriba.hidden=false;
        self.abajo.enabled=true;
        self.abajo.hidden=false;
        self.izquierda.enabled=true;
        self.izquierda.hidden=false;
        self.derecha.enabled=true;
        self.derecha.hidden=false;
    }
}


//Permitiremos moverse al jugador siempre y  cuando la casilla exista y no la esté ocupando otro personaje y el personaje se pueda mover
-(bool)movimiento{
    bool puedeHacerlo=false;
    if(contadorAcciones>0){
        puedeHacerlo=true;
        if([[player1 objectForKey:@"movimiento"]intValue]==0){
            contadorAcciones=contadorAcciones-1;
            if([[player1 objectForKey:@"nombre"]isEqualToString:[heroe1 valueForKey:@"nombre"]]){
                [player1 setValue:[NSString stringWithFormat:@"%i",[[heroe1 valueForKey:@"movimiento"]intValue]-1] forKey:@"movimiento"];
            }
            else if([[player1 objectForKey:@"nombre"]isEqualToString:[heroe2 valueForKey:@"nombre"]]){
                [player1 setValue:[NSString stringWithFormat:@"%i",[[heroe2 valueForKey:@"movimiento"]intValue]-1] forKey:@"movimiento"];
            }
            else if([[player1 objectForKey:@"nombre"]isEqualToString:[heroe3 valueForKey:@"nombre"]]){
                [player1 setValue:[NSString stringWithFormat:@"%i",[[heroe3 valueForKey:@"movimiento"]intValue]-1] forKey:@"movimiento"];
            }
            else{
                [player1 setValue:[NSString stringWithFormat:@"%i",[[heroe4 valueForKey:@"movimiento"]intValue]-1] forKey:@"movimiento"];
            }
        }
    }
    return puedeHacerlo;
}

- (IBAction)botonArriba:(id)sender {
    if([self movimiento]&&[[player1 objectForKey:@"movimiento"]intValue]>0&&posicion1>0&&[[[tablero objectAtIndex:posicion1-1]objectAtIndex:posicion2]isEqualToString:@"0"]){
        [player1 setValue:[NSString stringWithFormat:@"%i",[[player1 objectForKey:@"movimiento"]intValue]-1] forKey:@"movimiento"];
        
        int posicionx=posicion1;
        int posiciony=posicion2;
        
        [[tablero objectAtIndex:posicion1] replaceObjectAtIndex:posicion2 withObject:@"0"];
            posicion1=posicion1-1;
        [[tablero objectAtIndex:posicion1] replaceObjectAtIndex:posicion2 withObject:@"1"];
        
        [self comprobarPosicion:posicionx withPosicion:posiciony andPersonaje:player1];
    }
}

- (IBAction)botonAbajo:(id)sender {
    if([self movimiento]&&[[player1 objectForKey:@"movimiento"]intValue]>0&&posicion1<14&&[[[tablero objectAtIndex:posicion1+1]objectAtIndex:posicion2]isEqualToString:@"0"]){
        [player1 setValue:[NSString stringWithFormat:@"%i",[[player1 objectForKey:@"movimiento"]intValue]-1] forKey:@"movimiento"];
        
        int posicionx=posicion1;
        int posiciony=posicion2;
        
        [[tablero objectAtIndex:posicion1] replaceObjectAtIndex:posicion2 withObject:@"0"];
        posicion1=posicion1+1;
        [[tablero objectAtIndex:posicion1] replaceObjectAtIndex:posicion2 withObject:@"1"];
        
        [self comprobarPosicion:posicionx withPosicion:posiciony andPersonaje:player1];
    }
}

- (IBAction)botonIzquierda:(id)sender {
    if([self movimiento]&&[[player1 objectForKey:@"movimiento"]intValue]>0&&posicion2-1>-1&&[[[tablero objectAtIndex:posicion1]objectAtIndex:posicion2-1]isEqualToString:@"0"]){
        [player1 setValue:[NSString stringWithFormat:@"%i",[[player1 objectForKey:@"movimiento"]intValue]-1] forKey:@"movimiento"];
        
        int posicionx=posicion1;
        int posiciony=posicion2;
        
        [[tablero objectAtIndex:posicion1] replaceObjectAtIndex:posicion2 withObject:@"0"];
        posicion2=posicion2-1;
        [[tablero objectAtIndex:posicion1] replaceObjectAtIndex:posicion2 withObject:@"1"];
        
        [self comprobarPosicion:posicionx withPosicion:posiciony andPersonaje:player1];
    }
}

- (IBAction)botonDerecha:(id)sender {
    if([self movimiento]&&[[player1 objectForKey:@"movimiento"]intValue]>0&&posicion2+1<4&&[[[tablero objectAtIndex:posicion1]objectAtIndex:posicion2+1]isEqualToString:@"0"]){
        [player1 setValue:[NSString stringWithFormat:@"%i",[[player1 objectForKey:@"movimiento"]intValue]-1] forKey:@"movimiento"];
        
        int posicionx=posicion1;
        int posiciony=posicion2;
        
        [[tablero objectAtIndex:posicion1] replaceObjectAtIndex:posicion2 withObject:@"0"];
        posicion2=posicion2+1;
        [[tablero objectAtIndex:posicion1] replaceObjectAtIndex:posicion2 withObject:@"1"];
        
        [self comprobarPosicion:posicionx withPosicion:posiciony andPersonaje:player1];
    }
}


-(void)comprobarPosicion:(int)posicionx withPosicion:(int)posiciony andPersonaje:(NSMutableDictionary*)personaje{
    //Primero, eliminaremos al marcador del jugador de la posición en la que se encuentra, y lo moveremos a la posición nueva
    int posicionNuevaX=0;
    int posicionNuevaY=0;
    //Si el héroe se está moviendo, guardaremos sus coordenadas actuales
    if([[personaje objectForKey:@"nombre"]isEqualToString:[player1 objectForKey:@"nombre"]]){
        posicionNuevaX=posicion1;
        posicionNuevaY=posicion2;
    }
    //En caso contrario, trabajaremos con los monstruos
    else if([[personaje objectForKey:@"nombre"]isEqualToString:[minion1 objectForKey:@"nombre"]]){
        posicionNuevaX=posicionMinion1X;
        posicionNuevaY=posicionMinion1Y;
    }else if([[personaje objectForKey:@"nombre"]isEqualToString:[minion2 objectForKey:@"nombre"]]){
        posicionNuevaX=posicionMinion2X;
        posicionNuevaY=posicionMinion2Y;
    }else if([[personaje objectForKey:@"nombre"]isEqualToString:[minion3 objectForKey:@"nombre"]]){
        posicionNuevaX=posicionMinion3X;
        posicionNuevaY=posicionMinion3Y;
    }else if([[personaje objectForKey:@"nombre"]isEqualToString:[minion4 objectForKey:@"nombre"]]){
        posicionNuevaX=posicionMinion4X;
        posicionNuevaY=posicionMinion4Y;
    }else if([[personaje objectForKey:@"nombre"]isEqualToString:[minion5 objectForKey:@"nombre"]]){
        posicionNuevaX=posicionMinion5X;
        posicionNuevaY=posicionMinion5Y;
    }else if([[personaje objectForKey:@"nombre"]isEqualToString:[boss objectForKey:@"nombre"]]){
        posicionNuevaX=posicionMinionBX;
        posicionNuevaY=posicionMinionBY;
    }
    
    switch (posicionx) {
        //PASILLO 1
        case 0:
            switch (posiciony) {
                case 1:                    self.pasillo11.backgroundColor=nil;break;
                case 2:                    self.pasillo12.backgroundColor=nil;break;
            }
            break;
            
        case 1:
            switch (posiciony) {
                case 0: self.pasillo13.backgroundColor=nil;break;
                case 1: self.pasillo14.backgroundColor=nil;break;
                case 2: self.pasillo15.backgroundColor=nil;break;
                case 3: self.pasillo16.backgroundColor=nil;break;
            }
            break;
            
        case 2:
            switch (posiciony) {
                case 1: self.pasillo17.backgroundColor=nil;break;
                case 2: self.pasillo18.backgroundColor=nil;break;
            }
            break;
            
        case 3:
            switch (posiciony) {
                case 0: self.pasillo19.backgroundColor=nil;break;
                case 1: self.pasillo110.backgroundColor=nil;break;
                case 2: self.pasillo111.backgroundColor=nil;break;
                case 3: self.pasillo112.backgroundColor=nil;break;
            }
            break;
            
        case 4:
            switch (posiciony) {
                case 1: self.pasillo113.backgroundColor=nil;break;
                case 2: self.pasillo114.backgroundColor=nil;break;
            }
            break;
            
        //PASILLO 2
        case 5:
            switch (posiciony) {
                case 1:
                    if([[personaje objectForKey:@"nombre"]isEqualToString:[player1 objectForKey:@"nombre"]]){self.pasillo21.backgroundColor=nil;
                    }else{[self.pasillo21 setBackgroundImage:false forState:UIControlStateNormal];}break;
                case 2:
                    if([[personaje objectForKey:@"nombre"]isEqualToString:[player1 objectForKey:@"nombre"]]){self.pasillo22.backgroundColor=nil;
                }else{[self.pasillo22 setBackgroundImage:false forState:UIControlStateNormal];}break;
            }
            break;
            
        case 6:
            switch (posiciony) {
                case 0:
                    if([[personaje objectForKey:@"nombre"]isEqualToString:[player1 objectForKey:@"nombre"]]){self.pasillo23.backgroundColor=nil;
                    }else{[self.pasillo23 setBackgroundImage:false forState:UIControlStateNormal];}break;
                case 1:
                    if([[personaje objectForKey:@"nombre"]isEqualToString:[player1 objectForKey:@"nombre"]]){self.pasillo24.backgroundColor=nil;
                    }else{[self.pasillo24 setBackgroundImage:false forState:UIControlStateNormal];}break;
                case 2:
                    if([[personaje objectForKey:@"nombre"]isEqualToString:[player1 objectForKey:@"nombre"]]){self.pasillo25.backgroundColor=nil;
                    }else{[self.pasillo25 setBackgroundImage:false forState:UIControlStateNormal];}break;
                case 3:
                    if([[personaje objectForKey:@"nombre"]isEqualToString:[player1 objectForKey:@"nombre"]]){self.pasillo26.backgroundColor=nil;
                    }else{[self.pasillo26 setBackgroundImage:false forState:UIControlStateNormal];}break;
            }
            break;
            
        case 7:
            switch (posiciony) {
                case 1:
                    if([[personaje objectForKey:@"nombre"]isEqualToString:[player1 objectForKey:@"nombre"]]){self.pasillo27.backgroundColor=nil;
                    }else{[self.pasillo27 setBackgroundImage:false forState:UIControlStateNormal];}break;
                case 2:
                    if([[personaje objectForKey:@"nombre"]isEqualToString:[player1 objectForKey:@"nombre"]]){self.pasillo28.backgroundColor=nil;
                    }else{[self.pasillo28 setBackgroundImage:false forState:UIControlStateNormal];}break;
            }
            break;
            
        case 8:
            switch (posiciony) {
                case 1:
                    if([[personaje objectForKey:@"nombre"]isEqualToString:[player1 objectForKey:@"nombre"]]){self.pasillo29.backgroundColor=nil;
                    }else{[self.pasillo29 setBackgroundImage:false forState:UIControlStateNormal];}break;
                case 2:
                    if([[personaje objectForKey:@"nombre"]isEqualToString:[player1 objectForKey:@"nombre"]]){self.pasillo210.backgroundColor=nil;
                    }else{[self.pasillo210 setBackgroundImage:false forState:UIControlStateNormal];}break;
            }
            break;
            
        case 9:
            switch (posiciony) {
                case 1:
                    if([[personaje objectForKey:@"nombre"]isEqualToString:[player1 objectForKey:@"nombre"]]){self.pasillo211.backgroundColor=nil;
                    }else{
                        [self.pasillo211 setBackgroundImage:false forState:UIControlStateNormal];
                        
                    }break;
                case 2:
                    if([[personaje objectForKey:@"nombre"]isEqualToString:[player1 objectForKey:@"nombre"]]){self.pasillo212.backgroundColor=nil;
                    }else{[self.pasillo212 setBackgroundImage:false forState:UIControlStateNormal];}break;
            }
            break;
        
        //SALÓN
        case 10:
            switch (posiciony) {
                case 0:
                    if([[personaje objectForKey:@"nombre"]isEqualToString:[player1 objectForKey:@"nombre"]]){self.salon1.backgroundColor=nil;}
                    else{[self.salon1 setBackgroundImage:false forState:UIControlStateNormal];}break;
                case 1:
                    if([[personaje objectForKey:@"nombre"]isEqualToString:[player1 objectForKey:@"nombre"]]){self.salon2.backgroundColor=nil;}
                else{[self.salon2 setBackgroundImage:false forState:UIControlStateNormal];}break;
                case 2:
                    if([[personaje objectForKey:@"nombre"]isEqualToString:[player1 objectForKey:@"nombre"]]){self.salon3.backgroundColor=nil;}
                else{[self.salon3 setBackgroundImage:false forState:UIControlStateNormal];}break;
                case 3:
                    if([[personaje objectForKey:@"nombre"]isEqualToString:[player1 objectForKey:@"nombre"]]){self.salon4.backgroundColor=nil;}
                    else{[self.salon4 setBackgroundImage:false forState:UIControlStateNormal];}break;
            }
            break;
            
        case 11:
            switch (posiciony) {
                case 0:
                    if([[personaje objectForKey:@"nombre"]isEqualToString:[player1 objectForKey:@"nombre"]]){self.salon5.backgroundColor=nil;}
                    else{[self.salon5 setBackgroundImage:false forState:UIControlStateNormal];}break;
                case 1:
                    if([[personaje objectForKey:@"nombre"]isEqualToString:[player1 objectForKey:@"nombre"]]){self.salon6.backgroundColor=nil;}
                    else{[self.salon6 setBackgroundImage:false forState:UIControlStateNormal];}break;
                case 2:
                    if([[personaje objectForKey:@"nombre"]isEqualToString:[player1 objectForKey:@"nombre"]]){self.salon7.backgroundColor=nil;}
                    else{[self.salon7 setBackgroundImage:false forState:UIControlStateNormal];}break;
                case 3:
                    if([[personaje objectForKey:@"nombre"]isEqualToString:[player1 objectForKey:@"nombre"]]){self.salon8.backgroundColor=nil;}
                    else{[self.salon8 setBackgroundImage:false forState:UIControlStateNormal];}break;
            }
            break;
            
        case 12:
            switch (posiciony) {
                case 0:
                    if([[personaje objectForKey:@"nombre"]isEqualToString:[player1 objectForKey:@"nombre"]]){self.salon9.backgroundColor=nil;}
                    else{[self.salon9 setBackgroundImage:false forState:UIControlStateNormal];}break;
                case 1:
                    if([[personaje objectForKey:@"nombre"]isEqualToString:[player1 objectForKey:@"nombre"]]){self.salon10.backgroundColor=nil;}
                    else{[self.salon10 setBackgroundImage:false forState:UIControlStateNormal];}break;
                case 2:
                    if([[personaje objectForKey:@"nombre"]isEqualToString:[player1 objectForKey:@"nombre"]]){self.salon11.backgroundColor=nil;}
                    else{[self.salon11 setBackgroundImage:false forState:UIControlStateNormal];}break;
                case 3:
                    if([[personaje objectForKey:@"nombre"]isEqualToString:[player1 objectForKey:@"nombre"]]){self.salon12.backgroundColor=nil;}
                    else{[self.salon12 setBackgroundImage:false forState:UIControlStateNormal];}break;
            }
            break;
        
        //SALIDA
        case 13:
            switch (posiciony) {
                case 1:
                    if([[personaje objectForKey:@"nombre"]isEqualToString:[player1 objectForKey:@"nombre"]]){self.salida1.backgroundColor=nil;}
                    else{[self.salida1 setBackgroundImage:false forState:UIControlStateNormal];}break;
                case 2:
                    if([[personaje objectForKey:@"nombre"]isEqualToString:[player1 objectForKey:@"nombre"]]){self.salida2.backgroundColor=nil;}
                else{[self.salida2 setBackgroundImage:false forState:UIControlStateNormal];}break;
            }
            break;
            
        case 14:
            switch (posiciony) {
                case 1:
                    if([[personaje objectForKey:@"nombre"]isEqualToString:[player1 objectForKey:@"nombre"]]){self.salida3.backgroundColor=nil;}
                else{[self.salida3 setBackgroundImage:false forState:UIControlStateNormal];}break;
                case 2:
                    if([[personaje objectForKey:@"nombre"]isEqualToString:[player1 objectForKey:@"nombre"]]){self.salida4.backgroundColor=nil;}
                else{[self.salida4 setBackgroundImage:false forState:UIControlStateNormal];}break;
            }
            break;
    }
    
    
    //Ahora, recolocamos al personaje en su posición actual
    switch (posicionNuevaX) {
        //PASILLO 1
        case 0:
            switch (posicionNuevaY) {
                case 1: self.pasillo11.backgroundColor=[UIColor redColor];break;
                case 2: self.pasillo12.backgroundColor=[UIColor redColor];break;
            }
            break;
            
        case 1:
            switch (posicionNuevaY) {
                case 0: self.pasillo13.backgroundColor=[UIColor redColor];
                    break;
                case 1: self.pasillo14.backgroundColor=[UIColor redColor];
                    break;
                case 2: self.pasillo15.backgroundColor=[UIColor redColor];
                    break;
                case 3: self.pasillo16.backgroundColor=[UIColor redColor];
                    break;
            }
            break;
            
        case 2:
            switch (posicionNuevaY) {
                case 1: self.pasillo17.backgroundColor=[UIColor redColor];
                    break;
                case 2: self.pasillo18.backgroundColor=[UIColor redColor];
                    break;
            }
            break;
            
        case 3:
            switch (posicionNuevaY) {
                case 0: self.pasillo19.backgroundColor=[UIColor redColor];
                    break;
                case 1: self.pasillo110.backgroundColor=[UIColor redColor];
                    break;
                case 2: self.pasillo111.backgroundColor=[UIColor redColor];
                    break;
                case 3: self.pasillo112.backgroundColor=[UIColor redColor];
                    break;
            }
            break;
            
        case 4:
            switch (posicionNuevaY) {
                case 1: self.pasillo113.backgroundColor=[UIColor redColor];
                    break;
                case 2: self.pasillo114.backgroundColor=[UIColor redColor];
                    break;
            }
            break;
            
        //PASILLO 2
        case 5:
            switch (posicionNuevaY) {
                case 1:
                    if([[personaje objectForKey:@"tipo"] isEqualToString:@"zombie"]){
                    self.pasillo21.backgroundColor=nil;
                    [self.pasillo21 setBackgroundImage:[UIImage imageNamed:@"zombie.png" inBundle:[NSBundle bundleForClass:self.class] compatibleWithTraitCollection:nil] forState:UIControlStateNormal];
                }else{self.pasillo21.backgroundColor=[UIColor redColor];}break;
                case 2:
                    if([[personaje objectForKey:@"tipo"] isEqualToString:@"zombie"]){
                        self.pasillo22.backgroundColor=nil;
                        [self.pasillo22 setBackgroundImage:[UIImage imageNamed:@"zombie.png" inBundle:[NSBundle bundleForClass:self.class] compatibleWithTraitCollection:nil] forState:UIControlStateNormal];
                    }else{self.pasillo22.backgroundColor=[UIColor redColor];}break;
            }
            break;
            
        case 6:
            switch (posicionNuevaY) {
                case 0:
                    if([[personaje objectForKey:@"tipo"] isEqualToString:@"zombie"]){
                        self.pasillo23.backgroundColor=nil;
                        [self.pasillo23 setBackgroundImage:[UIImage imageNamed:@"zombie.png" inBundle:[NSBundle bundleForClass:self.class] compatibleWithTraitCollection:nil] forState:UIControlStateNormal];
                    }else{self.pasillo23.backgroundColor=[UIColor redColor];}break;
                case 1:
                    if([[personaje objectForKey:@"tipo"] isEqualToString:@"zombie"]){
                self.pasillo24.backgroundColor=nil;
                [self.pasillo24 setBackgroundImage:[UIImage imageNamed:@"zombie.png" inBundle:[NSBundle bundleForClass:self.class] compatibleWithTraitCollection:nil] forState:UIControlStateNormal];
            }else{self.pasillo24.backgroundColor=[UIColor redColor];}break;
                case 2:
                if([[personaje objectForKey:@"tipo"] isEqualToString:@"zombie"]){
                    self.pasillo25.backgroundColor=nil;
                    [self.pasillo25 setBackgroundImage:[UIImage imageNamed:@"zombie.png" inBundle:[NSBundle bundleForClass:self.class] compatibleWithTraitCollection:nil] forState:UIControlStateNormal];
                }else{self.pasillo25.backgroundColor=[UIColor redColor];}break;
                case 3:
                if([[personaje objectForKey:@"tipo"] isEqualToString:@"zombie"]){
                    self.pasillo26.backgroundColor=nil;
                    [self.pasillo26 setBackgroundImage:[UIImage imageNamed:@"zombie.png" inBundle:[NSBundle bundleForClass:self.class] compatibleWithTraitCollection:nil] forState:UIControlStateNormal];
                }else{self.pasillo26.backgroundColor=[UIColor redColor];}break;
            }
            break;
            
        case 7:
            switch (posicionNuevaY) {
                case 1:
                    if([[personaje objectForKey:@"tipo"] isEqualToString:@"zombie"]){
                    self.pasillo27.backgroundColor=nil;
                    [self.pasillo27 setBackgroundImage:[UIImage imageNamed:@"zombie.png" inBundle:[NSBundle bundleForClass:self.class] compatibleWithTraitCollection:nil] forState:UIControlStateNormal];
                }else{self.pasillo27.backgroundColor=[UIColor redColor];}break;
                case 2:
                    if([[personaje objectForKey:@"tipo"] isEqualToString:@"zombie"]){
                self.pasillo28.backgroundColor=nil;
                [self.pasillo28 setBackgroundImage:[UIImage imageNamed:@"zombie.png" inBundle:[NSBundle bundleForClass:self.class] compatibleWithTraitCollection:nil] forState:UIControlStateNormal];
            }else{self.pasillo28.backgroundColor=[UIColor redColor];}break;
            }
            break;
            
        case 8:
            switch (posicionNuevaY) {
                case 1:
                    if([[personaje objectForKey:@"tipo"] isEqualToString:@"zombie"]){
                        self.pasillo29.backgroundColor=nil;
                        [self.pasillo29 setBackgroundImage:[UIImage imageNamed:@"zombie.png" inBundle:[NSBundle bundleForClass:self.class] compatibleWithTraitCollection:nil] forState:UIControlStateNormal];
                    }else{self.pasillo29.backgroundColor=[UIColor redColor];}break;
                case 2:
                    if([[personaje objectForKey:@"tipo"] isEqualToString:@"zombie"]){
                        self.pasillo210.backgroundColor=nil;
                        [self.pasillo210 setBackgroundImage:[UIImage imageNamed:@"zombie.png" inBundle:[NSBundle bundleForClass:self.class] compatibleWithTraitCollection:nil] forState:UIControlStateNormal];
                    }else{self.pasillo210.backgroundColor=[UIColor redColor];}break;
            }
            break;
            
        case 9:
            switch (posicionNuevaY) {
                case 1:
                    if([[personaje objectForKey:@"tipo"] isEqualToString:@"zombie"]){
                    self.pasillo211.backgroundColor=nil;
                    [self.pasillo211 setBackgroundImage:[UIImage imageNamed:@"zombie.png" inBundle:[NSBundle bundleForClass:self.class] compatibleWithTraitCollection:nil] forState:UIControlStateNormal];
                    }else{self.pasillo211.backgroundColor=[UIColor redColor];}break;
                case 2:
                    if([[personaje objectForKey:@"tipo"] isEqualToString:@"zombie"]){
                    self.pasillo212.backgroundColor=nil;
                    [self.pasillo212 setBackgroundImage:[UIImage imageNamed:@"zombie.png" inBundle:[NSBundle bundleForClass:self.class] compatibleWithTraitCollection:nil] forState:UIControlStateNormal];
                }else{self.pasillo212.backgroundColor=[UIColor redColor];}break;
            }
            break;
            
        //SALÓN
        case 10:
            switch (posicionNuevaY) {
                case 0:
                    if([[personaje objectForKey:@"tipo"] isEqualToString:@"zombie"]){
                        self.salon1.backgroundColor=nil;
                        [self.salon1 setBackgroundImage:[UIImage imageNamed:@"zombie.png" inBundle:[NSBundle bundleForClass:self.class] compatibleWithTraitCollection:nil] forState:UIControlStateNormal];
                    }else{self.salon1.backgroundColor=[UIColor redColor];}break;
                case 1:
                    if([[personaje objectForKey:@"tipo"] isEqualToString:@"zombie"]){
                    self.salon2.backgroundColor=nil;
                    [self.salon2 setBackgroundImage:[UIImage imageNamed:@"zombie.png" inBundle:[NSBundle bundleForClass:self.class] compatibleWithTraitCollection:nil] forState:UIControlStateNormal];
                }else{self.salon2.backgroundColor=[UIColor redColor];}break;
                case 2:
                    if([[personaje objectForKey:@"tipo"] isEqualToString:@"zombie"]){
                    self.salon3.backgroundColor=nil;
                    [self.salon3 setBackgroundImage:[UIImage imageNamed:@"zombie.png" inBundle:[NSBundle bundleForClass:self.class] compatibleWithTraitCollection:nil] forState:UIControlStateNormal];
                }else{self.salon3.backgroundColor=[UIColor redColor];}break;
                case 3:
                    if([[personaje objectForKey:@"tipo"] isEqualToString:@"zombie"]){
                    self.salon4.backgroundColor=nil;
                    [self.salon4 setBackgroundImage:[UIImage imageNamed:@"zombie.png" inBundle:[NSBundle bundleForClass:self.class] compatibleWithTraitCollection:nil] forState:UIControlStateNormal];
                }else{self.salon4.backgroundColor=[UIColor redColor];}break;
            }
            break;
            
        case 11:
            switch (posicionNuevaY) {
                case 0:
                    if([[personaje objectForKey:@"tipo"] isEqualToString:@"zombie"]){
                        self.salon5.backgroundColor=nil;
                        [self.salon5 setBackgroundImage:[UIImage imageNamed:@"zombie.png" inBundle:[NSBundle bundleForClass:self.class] compatibleWithTraitCollection:nil] forState:UIControlStateNormal];
                    }
                    else{self.salon5.backgroundColor=[UIColor redColor];}break;
                case 1:
                    if([[personaje objectForKey:@"tipo"] isEqualToString:@"zombie"]){
                        self.salon6.backgroundColor=nil;
                        [self.salon6 setBackgroundImage:[UIImage imageNamed:@"zombie.png" inBundle:[NSBundle bundleForClass:self.class] compatibleWithTraitCollection:nil] forState:UIControlStateNormal];
                    }
                    else{self.salon6.backgroundColor=[UIColor redColor];}break;
                case 2:
                    if([[personaje objectForKey:@"tipo"] isEqualToString:@"zombie"]){
                    self.salon7.backgroundColor=nil;
                    [self.salon7 setBackgroundImage:[UIImage imageNamed:@"zombie.png" inBundle:[NSBundle bundleForClass:self.class] compatibleWithTraitCollection:nil] forState:UIControlStateNormal];
                }
                else{self.salon7.backgroundColor=[UIColor redColor];}break;
                case 3:
                    if([[personaje objectForKey:@"tipo"] isEqualToString:@"zombie"]){
                    self.salon8.backgroundColor=nil;
                    [self.salon8 setBackgroundImage:[UIImage imageNamed:@"zombie.png" inBundle:[NSBundle bundleForClass:self.class] compatibleWithTraitCollection:nil] forState:UIControlStateNormal];
                }else{self.salon8.backgroundColor=[UIColor redColor];}break;
            }
            break;
            
        case 12:
            switch (posicionNuevaY) {
                case 0:
                    if([[personaje objectForKey:@"tipo"] isEqualToString:@"zombie"]){
                        self.salon9.backgroundColor=nil;
                        [self.salon9 setBackgroundImage:[UIImage imageNamed:@"zombie.png" inBundle:[NSBundle bundleForClass:self.class] compatibleWithTraitCollection:nil] forState:UIControlStateNormal];
                    } else{self.salon9.backgroundColor=[UIColor redColor];}break;
                case 1:
                    if([[personaje objectForKey:@"tipo"] isEqualToString:@"zombie"]){
                        self.salon10.backgroundColor=nil;
                        [self.salon10 setBackgroundImage:[UIImage imageNamed:@"zombie.png" inBundle:[NSBundle bundleForClass:self.class] compatibleWithTraitCollection:nil] forState:UIControlStateNormal];
                    } else{self.salon10.backgroundColor=[UIColor redColor];}break;
                case 2:
                    if([[personaje objectForKey:@"tipo"] isEqualToString:@"zombie"]){
                        self.salon11.backgroundColor=nil;
                        [self.salon11 setBackgroundImage:[UIImage imageNamed:@"zombie.png" inBundle:[NSBundle bundleForClass:self.class] compatibleWithTraitCollection:nil] forState:UIControlStateNormal];
                    } else{self.salon11.backgroundColor=[UIColor redColor];}break;
                case 3:
                    if([[personaje objectForKey:@"tipo"] isEqualToString:@"zombie"]){
                        self.salon12.backgroundColor=nil;
                        [self.salon12 setBackgroundImage:[UIImage imageNamed:@"zombie.png" inBundle:[NSBundle bundleForClass:self.class] compatibleWithTraitCollection:nil] forState:UIControlStateNormal];
                    } else{self.salon12.backgroundColor=[UIColor redColor];}break;
            }
            break;
        
        //SALIDA
        case 13:
            switch (posicionNuevaY) {
                case 1:
                    if([[personaje objectForKey:@"tipo"] isEqualToString:@"zombie"]){
                    self.salida1.backgroundColor=nil;
                    [self.salida1 setBackgroundImage:[UIImage imageNamed:@"zombie.png" inBundle:[NSBundle bundleForClass:self.class] compatibleWithTraitCollection:nil] forState:UIControlStateNormal];
                } else{self.salida1.backgroundColor=[UIColor redColor];}break;
                case 2: if([[personaje objectForKey:@"tipo"] isEqualToString:@"zombie"]){
                    self.salida2.backgroundColor=nil;
                    [self.salida2 setBackgroundImage:[UIImage imageNamed:@"zombie.png" inBundle:[NSBundle bundleForClass:self.class] compatibleWithTraitCollection:nil] forState:UIControlStateNormal];
                } else{self.salida2.backgroundColor=[UIColor redColor];}break;
            }
            break;
            
        case 14:
            switch (posicionNuevaY) {
                case 1: if([[personaje objectForKey:@"tipo"] isEqualToString:@"zombie"]){
                    self.salida1.backgroundColor=nil;
                    [self.salida3 setBackgroundImage:[UIImage imageNamed:@"zombie.png" inBundle:[NSBundle bundleForClass:self.class] compatibleWithTraitCollection:nil] forState:UIControlStateNormal];
                } else{self.salida3.backgroundColor=[UIColor redColor];}break;
                case 2:
                    if([[personaje objectForKey:@"tipo"] isEqualToString:@"zombie"]){
                    self.salida4.backgroundColor=nil;
                    [self.salida4 setBackgroundImage:[UIImage imageNamed:@"zombie.png" inBundle:[NSBundle bundleForClass:self.class] compatibleWithTraitCollection:nil] forState:UIControlStateNormal];
                } else{self.salida4.backgroundColor=[UIColor redColor];}break;
            }break;
    }
}
- (IBAction)terminar:(id)sender {
    [self alertas:@"Mensaje" withMessage:@"Turno del rival"];
    [self accionesPNJ];
    [self turnosJuego];
}

//Cada turno, los monstruos se moverán y atacarán
-(void)accionesPNJ{
    //Si está en el pasillo 2, 1 minion se acercará al personaje y le atacará
    bool cerca=false;
   
   //Si el minion está cerca del héroe, le atacará 2 veces. Si no, se moverá
    if((posicion1==posicionMinion1X-1&&posicion2==posicionMinion1Y-1)||(posicion1==posicionMinion1X-1&&posicion2==posicionMinion1Y)||(posicion1==posicionMinion1X-1&&posicion2==posicionMinion1Y+1)||(posicion1==posicionMinion1X&&posicion2==posicionMinion1Y-1)||(posicion1==posicionMinion1X+1&&posicion2==posicionMinion1Y+1)||(posicion1==posicionMinion1X+1&&posicion2==posicionMinion1Y-1)||(posicion1==posicionMinion1X+1&&posicion2==posicionMinion1Y)||(posicion1==posicionMinion1X+1&&posicion2==posicionMinion1Y+1)){
        cerca=true;
    }
    
    //Si el minion no está cerca, se acercará al héroe, y atacará si se encuentra a no más de 8 casillas. Si no, realizará 2 ataques
    if(cerca){
        [self pelea:minion1 withPersonaje:player1];
        [self pelea:minion1 withPersonaje:player1];
    }
    else if(!cerca&&(posicion1-posicionMinion1Y==4||posicion1-posicionMinion1Y==-4)){
        [self moverMinion];
        [self pelea:minion1 withPersonaje:player1];
    }
    else{
        [self moverMinion];
    }
    [self alertas:@"Mensaje" withMessage:@"Minion ataca"];
    [self alertas:@"Mensaje" withMessage:@"Turno del héroe"];
}

-(void)moverMinion{
    int antesPos1=posicionMinion1X;
    int antesPos2=posicionMinion1Y;
    if((posicion1>=5&&posicion1<=14)&&(posicion2==1||posicion2==2)){
        //Si hay un espacio delante del héroe, lo ocuparemos con el monstruo del pasillo
        if([[[tablero objectAtIndex:posicion1+1]objectAtIndex:posicion2]isEqualToString:@"0"]){
            [[tablero objectAtIndex:posicionMinion1X] replaceObjectAtIndex:posicionMinion1Y withObject:@"0"];
            posicionMinion1X=posicion1+1;
            [[tablero objectAtIndex:posicionMinion1X] replaceObjectAtIndex:posicionMinion1Y withObject:@"2"];
            [self comprobarPosicion:antesPos1 withPosicion:antesPos2 andPersonaje:minion1];
        }
        //En caso contrario, lo colocaremos justo al lado en la línea siguiente a la del héroe
        else if([[[tablero objectAtIndex:posicion1+1]objectAtIndex:posicion2-1]isEqualToString:@"0"]){
            [[tablero objectAtIndex:posicionMinion1X] replaceObjectAtIndex:posicionMinion1Y withObject:@"0"];
            posicionMinion1X=posicion1+1;
            posicionMinion1Y=posicion2-1;
            [[tablero objectAtIndex:posicionMinion1X] replaceObjectAtIndex:posicionMinion1Y withObject:@"2"];
            [self comprobarPosicion:antesPos1 withPosicion:antesPos2 andPersonaje:minion1];
        }
        else if([[[tablero objectAtIndex:posicion1+1]objectAtIndex:posicion2+1]isEqualToString:@"0"]){
            [[tablero objectAtIndex:posicionMinion1X] replaceObjectAtIndex:posicionMinion1Y withObject:@"0"];
            posicionMinion1X=posicion1+1;
            posicionMinion1Y=posicion2-1;
            [[tablero objectAtIndex:posicionMinion1X] replaceObjectAtIndex:posicionMinion1Y withObject:@"2"];
            [self comprobarPosicion:antesPos1 withPosicion:antesPos2 andPersonaje:minion1];
        }
    }
}

//Comprobaremos si hay espacio para otro objeto en el inventario
-(bool)rellenarInventario{
    bool espacio=false;
    int espacioLibre=-1;
    for(int i=0;i<[inventarioHeroe1 count];i++){
        if([[[inventarioHeroe1 objectAtIndex:i]valueForKey:@"nombre"]isEqualToString:@""]&&espacioLibre==-1){
            espacio=true;
            espacioLibre=i;
        }
    }
    if(espacio){
        [self alertas:@"Mensaje" withMessage:@"Enhorabuena, tienes una Poción de Vida"];
        [[inventarioHeroe1 objectAtIndex:espacioLibre] setValue:@"Poción de Vida" forKey:@"nombre"];
        switch(espacioLibre){
            case 0:[self.boton1 setBackgroundImage:[UIImage imageNamed:@"Ultra_health_potion.png" inBundle:[NSBundle bundleForClass:self.class] compatibleWithTraitCollection:nil] forState:UIControlStateNormal];
                break;
            case 1:[self.boton2 setBackgroundImage:[UIImage imageNamed:@"Ultra_health_potion.png" inBundle:[NSBundle bundleForClass:self.class] compatibleWithTraitCollection:nil] forState:UIControlStateNormal];
                break;
            case 2:[self.boton3 setBackgroundImage:[UIImage imageNamed:@"Ultra_health_potion.png" inBundle:[NSBundle bundleForClass:self.class] compatibleWithTraitCollection:nil] forState:UIControlStateNormal];
                break;
            case 3:[self.boton4 setBackgroundImage:[UIImage imageNamed:@"Ultra_health_potion.png" inBundle:[NSBundle bundleForClass:self.class] compatibleWithTraitCollection:nil] forState:UIControlStateNormal];
                break;
            case 4:[self.boton5 setBackgroundImage:[UIImage imageNamed:@"Ultra_health_potion.png" inBundle:[NSBundle bundleForClass:self.class] compatibleWithTraitCollection:nil] forState:UIControlStateNormal];
                break;
            case 5:[self.boton6 setBackgroundImage:[UIImage imageNamed:@"Ultra_health_potion.png" inBundle:[NSBundle bundleForClass:self.class] compatibleWithTraitCollection:nil] forState:UIControlStateNormal];
                break;
            case 6:[self.boton7 setBackgroundImage:[UIImage imageNamed:@"Ultra_health_potion.png" inBundle:[NSBundle bundleForClass:self.class] compatibleWithTraitCollection:nil] forState:UIControlStateNormal];
                break;
            case 7:[self.boton8 setBackgroundImage:[UIImage imageNamed:@"Ultra_health_potion.png" inBundle:[NSBundle bundleForClass:self.class] compatibleWithTraitCollection:nil] forState:UIControlStateNormal];
                break;
            case 8:[self.boton9 setBackgroundImage:[UIImage imageNamed:@"Ultra_health_potion.png" inBundle:[NSBundle bundleForClass:self.class] compatibleWithTraitCollection:nil] forState:UIControlStateNormal];
                break;
            case 9:[self.boton10 setBackgroundImage:[UIImage imageNamed:@"Ultra_health_potion.png" inBundle:[NSBundle bundleForClass:self.class] compatibleWithTraitCollection:nil] forState:UIControlStateNormal];
                break;
            case 10:[self.boton11 setBackgroundImage:[UIImage imageNamed:@"Ultra_health_potion.png" inBundle:[NSBundle bundleForClass:self.class] compatibleWithTraitCollection:nil] forState:UIControlStateNormal];
                break;
            case 11:[self.boton12 setBackgroundImage:[UIImage imageNamed:@"Ultra_health_potion.png" inBundle:[NSBundle bundleForClass:self.class] compatibleWithTraitCollection:nil] forState:UIControlStateNormal];
                break;
                
        }
        
    }else{
        [self alertas:@"Mensaje" withMessage:@"No tienes espacio en el inventario para más objetos"];
    }
    return espacio;
}

- (IBAction)cofreIz:(id)sender {
    //Si un jugador se encuentra al lado de un cofre, podrá coger el objeto de su interior, y el cofre desaparecerá
    if([[[tablero objectAtIndex:6]objectAtIndex:1]isEqualToString:@"1"]&&
       [self rellenarInventario]){
    self.pasillo23.enabled=false;
    [self.pasillo23 setBackgroundImage:nil forState:UIControlStateNormal];
    [[tablero objectAtIndex:6] replaceObjectAtIndex:0 withObject:@"0"];
    }
}

- (IBAction)cofreDe:(id)sender {
    if([[[tablero objectAtIndex:6]objectAtIndex:2]isEqualToString:@"1"]&&
       [self rellenarInventario]){
        self.pasillo26.enabled=false;
        [self.pasillo26 setBackgroundImage:nil forState:UIControlStateNormal];
        [[tablero objectAtIndex:6] replaceObjectAtIndex:3 withObject:@"0"];
    }
}

//Si aún puede realizar 1 acción, y el monstruo a atacar se encuentra cerca del héroe, el jugador podrá atacar
-(void)ataquePlayer:(int)posicionX withPosicion:(int)posicionY{
    bool sePuede=false;
    
    if(posicionX==(posicion1-1)&&posicionY==(posicion2-1)){sePuede=true;}
    else if(posicionX==(posicion1-1)&&posicionY==posicion2){sePuede=true;}
    else if(posicionX==(posicion1-1)&&posicionY==(posicion2+1)){sePuede=true;}
    else if(posicionX==posicion1&&posicionY==(posicion2-1)){sePuede=true;}
    else if(posicionX==posicion1&&posicionY==(posicion2+1)){sePuede=true;}
    else if(posicionX==(posicion1+1)&&posicionY==(posicion2-1)){sePuede=true;}
    else if(posicionX==(posicion1+1)&&posicionY==posicion2){sePuede=true;}
    else if(posicionX==(posicion1+1)&&posicionY==(posicion2+1)){sePuede=true;}
    
    if(sePuede&&contadorAcciones>0){
        contadorAcciones=contadorAcciones-1;
     if(posicionX==posicionMinion1X&&posicionY==posicionMinion1Y){[self pelea:player1 withPersonaje:minion1];}
     else if(posicionX==posicionMinion2X&&posicionY==posicionMinion2Y){[self pelea:player1 withPersonaje:minion2];}
     else if(posicionX==posicionMinion3X&&posicionY==posicionMinion3Y){[self pelea:player1 withPersonaje:minion3];}
     else if(posicionX==posicionMinion4X&&posicionY==posicionMinion4Y){[self pelea:player1 withPersonaje:minion4];}
     else if(posicionX==posicionMinion5X&&posicionY==posicionMinion5Y){[self pelea:player1 withPersonaje:minion5];}
     else if(posicionX==posicionMinionBX&&posicionY==posicionMinionBY){[self pelea:player1 withPersonaje:boss];}
    }
}

//Cada vez que pulsemos sobre una casilla, buscaremos si se encuentra un enemigo en esa posición, y en caso de que el jugador tenga al menos 1 acción disponible por realizar,permitiremos realizar el ataque contra el monstruo en esa posición
-(IBAction)pasillo21Accion:(id)sender{
    [self ataquePlayer:5 withPosicion:1];}
- (IBAction)pasillo22Accion:(id)sender{
    [self ataquePlayer:5 withPosicion:2];}
- (IBAction)pasillo23Accion:(id)sender{
    [self ataquePlayer:6 withPosicion:0];}
- (IBAction)pasillo24Accion:(id)sender{
    [self ataquePlayer:6 withPosicion:1];}
- (IBAction)pasillo25Accion:(id)sender{
    [self ataquePlayer:6 withPosicion:2];}
- (IBAction)pasillo26Accion:(id)sender{
    [self ataquePlayer:6 withPosicion:3];}
- (IBAction)pasillo27Accion:(id)sender{
    [self ataquePlayer:7 withPosicion:1];}
- (IBAction)pasillo28Accion:(id)sender{
    [self ataquePlayer:7 withPosicion:2];}
- (IBAction)pasillo29Accion:(id)sender{
    [self ataquePlayer:8 withPosicion:1];}
- (IBAction)pasillo210Accion:(id)sender{
    [self ataquePlayer:8 withPosicion:2];}
- (IBAction)pasillo211Accion:(id)sender{
    [self ataquePlayer:9 withPosicion:1];}
- (IBAction)pasillo212Accion:(id)sender{
    [self ataquePlayer:9 withPosicion:2];}

- (IBAction)salon1Accion:(id)sender{
    [self ataquePlayer:10 withPosicion:0];}
- (IBAction)salon2Accion:(id)sender{
    [self ataquePlayer:10 withPosicion:1];}
- (IBAction)salon3Accion:(id)sender{
    [self ataquePlayer:10 withPosicion:2];}
- (IBAction)salon4Accion:(id)sender{
    [self ataquePlayer:10 withPosicion:3];}
- (IBAction)salon5Accion:(id)sender{
    [self ataquePlayer:11 withPosicion:0];}
- (IBAction)salon6Accion:(id)sender{
    [self ataquePlayer:11 withPosicion:1];}
- (IBAction)salon7Accion:(id)sender{
    [self ataquePlayer:11 withPosicion:2];}
- (IBAction)salon8Accion:(id)sender{
    [self ataquePlayer:11 withPosicion:3];}
- (IBAction)salon9Accion:(id)sender{
    [self ataquePlayer:12 withPosicion:0];}
- (IBAction)salon10Accion:(id)sender{
    [self ataquePlayer:12 withPosicion:1];}
- (IBAction)salon11Accion:(id)sender{
    [self ataquePlayer:12 withPosicion:2];}
- (IBAction)salon12Accion:(id)sender{
    [self ataquePlayer:12 withPosicion:3];}

- (IBAction)salida1Accion:(id)sender{
    [self ataquePlayer:13 withPosicion:1];}
- (IBAction)salida2Accion:(id)sender{
    [self ataquePlayer:13 withPosicion:2];}
- (IBAction)salida3Accion:(id)sender{
    [self ataquePlayer:14 withPosicion:1];}
- (IBAction)salida4Accion:(id)sender{
    [self ataquePlayer:14 withPosicion:2];}

@end
